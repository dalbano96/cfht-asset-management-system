-- MySQL dump 10.14  Distrib 5.5.47-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: snipeit
-- ------------------------------------------------------
-- Server version	5.5.47-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessories`
--

DROP TABLE IF EXISTS `accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `requestable` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) DEFAULT NULL,
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessories`
--

LOCK TABLES `accessories` WRITE;
/*!40000 ALTER TABLE `accessories` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accessories_users`
--

DROP TABLE IF EXISTS `accessories_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessories_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessories_users`
--

LOCK TABLES `accessories_users` WRITE;
/*!40000 ALTER TABLE `accessories_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_logs`
--

DROP TABLE IF EXISTS `asset_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `checkedout_to` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `asset_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  `filename` text COLLATE utf8_unicode_ci,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `requested_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `accepted_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `expected_checkin` date DEFAULT NULL,
  `thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_logs_thread_id_index` (`thread_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_logs`
--

LOCK TABLES `asset_logs` WRITE;
/*!40000 ALTER TABLE `asset_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_maintenances`
--

DROP TABLE IF EXISTS `asset_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_maintenances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `asset_maintenance_type` enum('Maintenance','Repair','Upgrade') COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_warranty` tinyint(1) NOT NULL,
  `start_date` date NOT NULL,
  `completion_date` date DEFAULT NULL,
  `asset_maintenance_time` int(11) DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `cost` decimal(10,2) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_maintenances`
--

LOCK TABLES `asset_maintenances` WRITE;
/*!40000 ALTER TABLE `asset_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_uploads`
--

DROP TABLE IF EXISTS `asset_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `asset_id` int(11) NOT NULL,
  `filenotes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_uploads`
--

LOCK TABLES `asset_uploads` WRITE;
/*!40000 ALTER TABLE `asset_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `asset_tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) NOT NULL DEFAULT '0.0000',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `physical` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `warranty_months` int(3) DEFAULT NULL,
  `depreciate` tinyint(1) NOT NULL DEFAULT '0',
  `supplier_id` int(11) DEFAULT NULL,
  `requestable` tinyint(4) NOT NULL DEFAULT '0',
  `rtd_location_id` int(11) DEFAULT NULL,
  `accepted` enum('pending','accepted','rejected') COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_checkout` datetime DEFAULT NULL,
  `expected_checkin` date DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `_snipeit_model_chassis_backplane` text COLLATE utf8_unicode_ci,
  `_snipeit_motherboard` text COLLATE utf8_unicode_ci,
  `_snipeit_cpu` text COLLATE utf8_unicode_ci,
  `_snipeit_ram` text COLLATE utf8_unicode_ci,
  `_snipeit_storage` text COLLATE utf8_unicode_ci,
  `_snipeit_role` text COLLATE utf8_unicode_ci,
  `_snipeit_year` text COLLATE utf8_unicode_ci,
  `_snipeit_qr_code_url` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (1,'Akua','CFHT-1',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-06 20:36:17','2016-07-06 20:36:17',1,NULL,1,0,NULL,0,0,0,NULL,NULL,NULL,NULL,1,'','X7DWA-N','2 x Xeon E5450 3.00Ghz 4 cores each 8 cores total','16G','3ware 9650SE-8LPML 8 x 1TB in RAID 5  3ware 9650SE-8LPML 8 x 1TB in RAID 5  with Linux software raid','Home directories + processing for Astro group','2009','http://inventory.cfht.hawaii.edu/hardware/1/view'),(2,'Alohi','CFHT-2',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-06 20:46:52','2016-07-06 20:46:52',1,NULL,1,0,NULL,0,0,0,NULL,NULL,NULL,NULL,1,'Backplane SAS836TQ','ASUS Z8NA-D6','2 x Xeon E5506 2.13 Ghz','12G','3ware 9650SE-8LPML 8 x 1.82TB in RAID 5 3ware 9650SE-8LPML 8 x 1.82TB in RAID 5','Elixir rpm-httpd','','http://inventory.cfht.hawaii.edu/hardware/2/view'),(3,'Bifrost','CFHT-3',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-06 20:48:15','2016-07-06 20:48:15',1,NULL,1,0,NULL,0,0,0,NULL,NULL,NULL,NULL,1,'','X7DBP-8','2 x Xeon 5140 2.33Ghz','16G','4 x Seagate 73GB SCSI 10k','VMware ESXi production #2 Other VMs (hadoop cluster, etc.)','2008','http://inventory.cfht.hawaii.edu/hardware/3/view'),(4,'','CFHT-4',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-06 20:58:14','2016-07-06 20:58:33',1,'2016-07-06 20:58:33',3,0,NULL,0,0,0,NULL,NULL,NULL,NULL,NULL,'','','','','','','','http://inventory.cfht.hawaii.edu/hardware/4/view'),(5,'','CFHT-5',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-06 20:58:42','2016-07-06 20:59:11',1,'2016-07-06 20:59:11',3,0,NULL,0,0,0,NULL,NULL,NULL,NULL,NULL,'','','','','','','','http://inventory.cfht.hawaii.edu/hardware/5/view'),(6,'','CFHT-6',1,'654',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-06 21:03:05','2016-07-08 06:35:54',1,'2016-07-08 06:35:54',1,0,NULL,0,0,0,NULL,NULL,NULL,NULL,NULL,'','','','','','','','http://inventory.cfht.hawaii.edu/hardware/6/view'),(7,'I think I fixed it?','CFHT-7',1,'',NULL,0.0000,'',NULL,'',NULL,2,'2016-07-08 06:42:00','2016-07-08 06:42:00',1,NULL,1,0,NULL,0,0,0,NULL,NULL,NULL,NULL,1,'','','','','','','','https://inventory.cfht.hawaii.edu/hardware/7/view');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `eula_text` longtext COLLATE utf8_unicode_ci,
  `use_default_eula` tinyint(1) NOT NULL DEFAULT '0',
  `require_acceptance` tinyint(1) NOT NULL DEFAULT '0',
  `category_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'asset',
  `checkin_email` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Laptops','2016-06-18 23:48:39','2016-06-18 23:48:39',1,NULL,NULL,0,0,'asset',0),(2,'Desktops','2016-06-18 23:48:39','2016-06-18 23:48:39',1,NULL,NULL,0,0,'asset',0),(3,'Tablets','2016-06-18 23:48:39','2016-06-18 23:48:39',1,NULL,NULL,0,0,'asset',0),(4,'Phones','2016-06-18 23:48:39','2016-06-18 23:48:39',1,NULL,NULL,0,0,'accessory',0),(5,'Monitors','2016-06-18 23:48:39','2016-06-18 23:48:39',1,NULL,NULL,0,0,'accessory',0),(6,'Printer Ink','2016-06-18 23:48:39','2016-06-18 23:48:39',1,NULL,NULL,0,0,'consumable',0),(7,'Servers','2016-07-06 20:00:41','2016-07-06 20:00:41',1,NULL,'',0,0,'asset',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Canada France Hawaii Telescope','2016-07-06 19:59:08','2016-07-06 19:59:08');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumables`
--

DROP TABLE IF EXISTS `consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `requestable` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) DEFAULT NULL,
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumables`
--

LOCK TABLES `consumables` WRITE;
/*!40000 ALTER TABLE `consumables` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumables_users`
--

DROP TABLE IF EXISTS `consumables_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumables_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumables_users`
--

LOCK TABLES `consumables_users` WRITE;
/*!40000 ALTER TABLE `consumables_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_custom_fieldset`
--

DROP TABLE IF EXISTS `custom_field_custom_fieldset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_custom_fieldset` (
  `custom_field_id` int(11) NOT NULL,
  `custom_fieldset_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_custom_fieldset`
--

LOCK TABLES `custom_field_custom_fieldset` WRITE;
/*!40000 ALTER TABLE `custom_field_custom_fieldset` DISABLE KEYS */;
INSERT INTO `custom_field_custom_fieldset` VALUES (1,1,1,0),(3,2,1,0),(4,2,2,0),(5,2,3,0),(6,2,4,0),(7,2,5,0),(8,2,6,0),(9,2,7,0),(3,3,1,0),(4,3,2,0),(5,3,3,0),(6,3,4,0),(7,3,5,0),(8,3,6,0),(9,3,7,0);
/*!40000 ALTER TABLE `custom_field_custom_fieldset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `element` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` VALUES (3,'Model/Chassis/Backplane','','text','2016-07-06 20:04:33','2016-07-06 20:04:33',1),(4,'Motherboard','','text','2016-07-06 20:04:45','2016-07-06 20:04:45',1),(5,'CPU','','text','2016-07-06 20:04:57','2016-07-06 20:04:57',1),(6,'RAM','','text','2016-07-06 20:05:03','2016-07-06 20:05:03',1),(7,'Storage','','text','2016-07-06 20:05:09','2016-07-06 20:05:09',1),(8,'Role','','text','2016-07-06 20:05:43','2016-07-06 20:05:43',1),(9,'Year','','text','2016-07-06 20:06:02','2016-07-06 20:06:02',1),(10,'QR Code URL','','text','2016-07-06 20:33:07','2016-07-06 20:33:07',1);
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fieldsets`
--

DROP TABLE IF EXISTS `custom_fieldsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fieldsets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fieldsets`
--

LOCK TABLES `custom_fieldsets` WRITE;
/*!40000 ALTER TABLE `custom_fieldsets` DISABLE KEYS */;
INSERT INTO `custom_fieldsets` VALUES (3,'Components','2016-07-06 20:10:46','2016-07-06 20:10:46',1);
/*!40000 ALTER TABLE `custom_fieldsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depreciations`
--

DROP TABLE IF EXISTS `depreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depreciations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `months` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depreciations`
--

LOCK TABLES `depreciations` WRITE;
/*!40000 ALTER TABLE `depreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `depreciations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'Admin','{\"admin\":1,\"users\":1,\"reports\":1}','2016-07-01 23:48:39','2016-07-01 23:48:39'),(2,'Reporting','{\"users\":1,\"reports\":1}','2016-07-01 23:48:39','2016-07-01 23:48:39'),(3,'Users','{\"users\":1}','2016-07-01 23:48:39','2016-07-01 23:48:39');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `checkedout_to` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license_seats`
--

DROP TABLE IF EXISTS `license_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `license_seats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `license_id` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license_seats`
--

LOCK TABLES `license_seats` WRITE;
/*!40000 ALTER TABLE `license_seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `license_seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licenses`
--

DROP TABLE IF EXISTS `licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `serial` text COLLATE utf8_unicode_ci,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) DEFAULT NULL,
  `order_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seats` int(11) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `depreciation_id` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `license_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_email` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `depreciate` tinyint(1) DEFAULT '0',
  `supplier_id` int(11) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `purchase_order` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `termination_date` date DEFAULT NULL,
  `maintained` tinyint(1) NOT NULL,
  `reassignable` tinyint(1) NOT NULL DEFAULT '1',
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licenses`
--

LOCK TABLES `licenses` WRITE;
/*!40000 ALTER TABLE `licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `licenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `address` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Offices','Waimea','HI','US','2016-07-08 22:58:12','2016-07-08 22:58:12',2,'','','',NULL,NULL,'$'),(2,'Summit','Mauna Kea','HI','US','2016-07-08 22:58:37','2016-07-08 22:58:37',2,'','','',NULL,NULL,'$'),(3,'redprog','Waimea','','US','2016-07-08 23:12:33','2016-07-08 23:12:33',2,'','','',NULL,NULL,'$');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturers`
--

LOCK TABLES `manufacturers` WRITE;
/*!40000 ALTER TABLE `manufacturers` DISABLE KEYS */;
INSERT INTO `manufacturers` VALUES (1,'Other','2016-07-06 20:00:01','2016-07-06 20:00:01',1,NULL),(2,'Super Micro Computer inc.','2016-07-06 20:02:53','2016-07-06 20:02:53',1,NULL);
/*!40000 ALTER TABLE `manufacturers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2012_12_06_225921_migration_cartalyst_sentry_install_users',1),('2012_12_06_225929_migration_cartalyst_sentry_install_groups',1),('2012_12_06_225945_migration_cartalyst_sentry_install_users_groups_pivot',1),('2012_12_06_225988_migration_cartalyst_sentry_install_throttle',1),('2013_03_23_193214_update_users_table',2),('2013_11_13_075318_create_models_table',2),('2013_11_13_075335_create_categories_table',2),('2013_11_13_075347_create_manufacturers_table',2),('2013_11_15_015858_add_user_id_to_categories',2),('2013_11_15_112701_add_user_id_to_manufacturers',2),('2013_11_15_190327_create_assets_table',2),('2013_11_15_190357_create_licenses_table',2),('2013_11_15_201848_add_license_name_to_licenses',2),('2013_11_16_040323_create_depreciations_table',2),('2013_11_16_042851_add_depreciation_id_to_models',2),('2013_11_16_084923_add_user_id_to_models',2),('2013_11_16_103258_create_locations_table',2),('2013_11_16_103336_add_location_id_to_assets',2),('2013_11_16_103407_add_checkedout_to_to_assets',2),('2013_11_16_103425_create_history_table',2),('2013_11_17_054359_drop_licenses_table',2),('2013_11_17_054526_add_physical_to_assets',2),('2013_11_17_055126_create_settings_table',2),('2013_11_17_062634_add_license_to_assets',2),('2013_11_18_134332_add_contacts_to_users',2),('2013_11_18_142847_add_info_to_locations',2),('2013_11_18_152942_remove_location_id_from_asset',2),('2013_11_18_164423_set_nullvalues_for_user',2),('2013_11_19_013337_create_asset_logs_table',2),('2013_11_19_061409_edit_added_on_asset_logs_table',2),('2013_11_19_062250_edit_location_id_asset_logs_table',2),('2013_11_20_055822_add_soft_delete_on_assets',2),('2013_11_20_121404_add_soft_delete_on_locations',2),('2013_11_20_123137_add_soft_delete_on_manufacturers',2),('2013_11_20_123725_add_soft_delete_on_categories',2),('2013_11_20_130248_create_status_labels',2),('2013_11_20_130830_add_status_id_on_assets_table',2),('2013_11_20_131544_add_status_type_on_status_labels',2),('2013_11_20_134103_add_archived_to_assets',2),('2013_11_21_002321_add_uploads_table',2),('2013_11_21_024531_remove_deployable_boolean_from_status_labels',2),('2013_11_22_075308_add_option_label_to_settings_table',2),('2013_11_22_213400_edits_to_settings_table',2),('2013_11_25_013244_create_licenses_table',2),('2013_11_25_031458_create_license_seats_table',2),('2013_11_25_032022_add_type_to_actionlog_table',2),('2013_11_25_033008_delete_bad_licenses_table',2),('2013_11_25_033131_create_new_licenses_table',2),('2013_11_25_033534_add_licensed_to_licenses_table',2),('2013_11_25_101308_add_warrantee_to_assets_table',2),('2013_11_25_104343_alter_warranty_column_on_assets',2),('2013_11_25_150450_drop_parent_from_categories',2),('2013_11_25_151920_add_depreciate_to_assets',2),('2013_11_25_152903_add_depreciate_to_licenses_table',2),('2013_11_26_211820_drop_license_from_assets_table',2),('2013_11_27_062510_add_note_to_asset_logs_table',2),('2013_12_01_113426_add_filename_to_asset_log',2),('2013_12_06_094618_add_nullable_to_licenses_table',2),('2013_12_10_084038_add_eol_on_models_table',2),('2013_12_12_055218_add_manager_to_users_table',2),('2014_01_28_031200_add_qr_code_to_settings_table',2),('2014_02_13_183016_add_qr_text_to_settings_table',2),('2014_05_24_093839_alter_default_license_depreciation_id',2),('2014_05_27_231658_alter_default_values_licenses',2),('2014_06_19_191508_add_asset_name_to_settings',2),('2014_06_20_004847_make_asset_log_checkedout_to_nullable',2),('2014_06_20_005050_make_asset_log_purchasedate_to_nullable',2),('2014_06_24_003011_add_suppliers',2),('2014_06_24_010742_add_supplier_id_to_asset',2),('2014_06_24_012839_add_zip_to_supplier',2),('2014_06_24_033908_add_url_to_supplier',2),('2014_07_08_054116_add_employee_id_to_users',2),('2014_07_09_134316_add_requestable_to_assets',2),('2014_07_17_085822_add_asset_to_software',2),('2014_07_17_161625_make_asset_id_in_logs_nullable',2),('2014_08_12_053504_alpha_0_4_2_release',2),('2014_08_17_083523_make_location_id_nullable',2),('2014_10_16_200626_add_rtd_location_to_assets',2),('2014_10_24_000417_alter_supplier_state_to_32',2),('2014_10_24_015641_add_display_checkout_date',2),('2014_10_28_222654_add_avatar_field_to_users_table',2),('2014_10_29_045924_add_image_field_to_models_table',2),('2014_11_01_214955_add_eol_display_to_settings',2),('2014_11_04_231416_update_group_field_for_reporting',2),('2014_11_05_212408_add_fields_to_licenses',2),('2014_11_07_021042_add_image_to_supplier',2),('2014_11_20_203007_add_username_to_user',2),('2014_11_20_223947_add_auto_to_settings',2),('2014_11_20_224421_add_prefix_to_settings',2),('2014_11_21_104401_change_licence_type',2),('2014_12_09_082500_add_fields_maintained_term_to_licenses',2),('2015_02_04_155757_increase_user_field_lengths',2),('2015_02_07_013537_add_soft_deleted_to_log',2),('2015_02_10_040958_fix_bad_assigned_to_ids',2),('2015_02_10_053310_migrate_data_to_new_statuses',2),('2015_02_11_044104_migrate_make_license_assigned_null',2),('2015_02_11_104406_migrate_create_requests_table',2),('2015_02_12_001312_add_mac_address_to_asset',2),('2015_02_12_024100_change_license_notes_type',2),('2015_02_17_231020_add_localonly_to_settings',2),('2015_02_19_222322_add_logo_and_colors_to_settings',2),('2015_02_24_072043_add_alerts_to_settings',2),('2015_02_25_022931_add_eula_fields',2),('2015_02_25_204513_add_accessories_table',2),('2015_02_26_091228_add_accessories_user_table',2),('2015_02_26_115128_add_deleted_at_models',2),('2015_02_26_233005_add_category_type',2),('2015_03_01_231912_update_accepted_at_to_acceptance_id',2),('2015_03_05_011929_add_qr_type_to_settings',2),('2015_03_18_055327_add_note_to_user',2),('2015_04_29_234704_add_slack_to_settings',2),('2015_05_04_085151_add_parent_id_to_locations_table',2),('2015_05_22_124421_add_reassignable_to_licenses',2),('2015_06_10_003314_fix_default_for_user_notes',2),('2015_06_10_003554_create_consumables',2),('2015_06_15_183253_move_email_to_username',2),('2015_06_23_070346_make_email_nullable',2),('2015_06_26_213716_create_asset_maintenances_table',2),('2015_07_04_212443_create_custom_fields_table',2),('2015_07_09_014359_add_currency_to_settings_and_locations',2),('2015_07_21_122022_add_expected_checkin_date_to_asset_logs',2),('2015_07_24_093845_add_checkin_email_to_category_table',2),('2015_07_25_055415_remove_email_unique_constraint',2),('2015_07_29_230054_add_thread_id_to_asset_logs_table',2),('2015_07_31_015430_add_accepted_to_assets',2),('2015_09_09_195301_add_custom_css_to_settings',2),('2015_09_21_235926_create_custom_field_custom_fieldset',2),('2015_09_22_000104_create_custom_fieldsets',2),('2015_09_22_003321_add_fieldset_id_to_assets',2),('2015_09_22_003413_migrate_mac_address',2),('2015_09_28_003314_fix_default_purchase_order',2),('2015_10_01_024551_add_accessory_consumable_price_info',2),('2015_10_12_192706_add_brand_to_settings',2),('2015_10_22_003314_fix_defaults_accessories',2),('2015_10_23_182625_add_checkout_time_and_expected_checkout_date_to_assets',2),('2015_11_05_061015_create_companies_table',2),('2015_11_05_061115_add_company_id_to_consumables_table',2),('2015_11_05_183749_image',2),('2015_11_06_092038_add_company_id_to_accessories_table',2),('2015_11_06_100045_add_company_id_to_users_table',2),('2015_11_06_134742_add_company_id_to_licenses_table',2),('2015_11_08_035832_add_company_id_to_assets_table',2),('2015_11_08_222305_add_ldap_fields_to_settings',2),('2015_11_15_151803_add_full_multiple_companies_support_to_settings_table',2),('2015_11_26_195528_import_ldap_settings',2),('2015_11_30_191504_remove_fk_company_id',2),('2015_12_21_193006_add_ldap_server_cert_ignore_to_settings_table',2),('2015_12_30_233509_add_timestamp_and_userId_to_custom_fields',2),('2015_12_30_233658_add_timestamp_and_userId_to_custom_fieldsets',2),('2016_01_28_041048_add_notes_to_models',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `modelno` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `depreciation_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `eol` int(11) DEFAULT '0',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deprecated_mac_address` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `fieldset_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'Supermicro','',2,7,'2016-07-06 20:03:57','2016-07-06 20:18:39',0,1,0,NULL,0,NULL,3,''),(2,'Test','',2,7,'2016-07-06 20:19:19','2016-07-06 20:33:37',0,1,0,NULL,0,'2016-07-06 20:33:37',3,'');
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requested_assets`
--

DROP TABLE IF EXISTS `requested_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requested_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `denied_at` datetime DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requested_assets`
--

LOCK TABLES `requested_assets` WRITE;
/*!40000 ALTER TABLE `requested_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `requested_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `request_code` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests`
--

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `per_page` int(11) NOT NULL DEFAULT '20',
  `site_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Snipe IT Asset Management',
  `qr_code` int(11) DEFAULT NULL,
  `qr_text` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_asset_name` int(11) DEFAULT NULL,
  `display_checkout_date` int(11) DEFAULT NULL,
  `display_eol` int(11) DEFAULT NULL,
  `auto_increment_assets` int(11) NOT NULL DEFAULT '0',
  `auto_increment_prefix` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `load_remote` tinyint(1) NOT NULL DEFAULT '1',
  `logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `header_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alert_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alerts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `default_eula_text` longtext COLLATE utf8_unicode_ci,
  `barcode_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'QRCODE',
  `slack_endpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slack_channel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slack_botname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `default_currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `custom_css` text COLLATE utf8_unicode_ci,
  `brand` tinyint(4) NOT NULL DEFAULT '1',
  `ldap_enabled` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_server` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_uname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_pword` longtext COLLATE utf8_unicode_ci,
  `ldap_basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'cn=*',
  `ldap_username_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'samaccountname',
  `ldap_lname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'sn',
  `ldap_fname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'givenname',
  `ldap_auth_filter_query` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid=samaccountname',
  `ldap_version` int(11) DEFAULT '3',
  `ldap_active_flag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_emp_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_multiple_companies_support` tinyint(1) NOT NULL DEFAULT '0',
  `ldap_server_cert_ignore` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'2016-07-01 23:48:39','2016-07-09 03:19:10',1,150,'Canada France Hawaii Telescope (BETA)',1,'Property of CFHT',NULL,NULL,NULL,1,'CFHT-',1,NULL,'#03A9F4','',1,'','QRCODE','','','','$','',1,'1','ldaps://kalij.cfht.hawaii.edu','uid=assetadmin,cn=users,cn=accounts,dc=cfht,dc=hawaii,dc=edu','eyJpdiI6IlNuc1dhVFpoYTc5ZmRVUXJLcHZrcWVWXC9la0pOM2Z3STc1QVJseGxOdmlnPSIsInZhbHVlIjoiUkRkdTR5cEMyTWtLc3VUNzlJMFJ1UWtiQUFENVNxa2JsOElXTmwrN2ZNST0iLCJtYWMiOiIwMmEzZTI2YjVjM2FkOWUwNmNmYzNjYjI0ZDc4OTA5MzdlZTIzZDgxOGI0MGMxODNlMWEzMWZkYWZjNDE1OWE5In0=','dc=cfht,dc=hawaii,dc=edu','&(objectclass=*)(memberof=cn=redprog,cn=groups,cn=accounts,dc=cfht,dc=hawaii,dc=edu)','uid','sn','givenname','uid=',3,'','','mail',0,1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status_labels`
--

DROP TABLE IF EXISTS `status_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_labels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deployable` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_labels`
--

LOCK TABLES `status_labels` WRITE;
/*!40000 ALTER TABLE `status_labels` DISABLE KEYS */;
INSERT INTO `status_labels` VALUES (1,'Ready to Deploy',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,1,0,0,''),(2,'Pending',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,0,1,0,''),(3,'Archived',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,0,0,1,'These assets are permanently undeployable'),(4,'Out for Diagnostics',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,0,0,0,''),(5,'Out for Repair',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,0,0,0,''),(6,'Broken - Not Fixable',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,0,0,1,''),(7,'Lost/Stolen',1,'2016-04-01 23:48:39','2016-04-01 23:48:39',NULL,0,0,1,'');
/*!40000 ALTER TABLE `status_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `throttle`
--

DROP TABLE IF EXISTS `throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `throttle`
--

LOCK TABLES `throttle` WRITE;
/*!40000 ALTER TABLE `throttle` DISABLE KEYS */;
INSERT INTO `throttle` VALUES (1,1,'10.80.10.53',0,0,0,NULL,NULL,NULL),(2,1,'128.171.80.232',0,0,0,NULL,NULL,NULL),(3,1,'10.80.10.98',0,0,0,NULL,NULL,NULL),(4,1,'10.80.10.177',0,0,0,NULL,NULL,NULL),(5,2,'10.80.10.188',0,0,0,NULL,NULL,NULL),(6,1,'10.80.10.188',0,0,0,NULL,NULL,NULL),(7,1,'10.80.10.94',0,0,0,NULL,NULL,NULL),(8,1,'10.80.10.94',1,0,0,'2016-07-06 21:17:26',NULL,NULL),(9,2,'10.80.10.53',0,0,0,NULL,NULL,NULL),(10,3,'10.80.10.53',0,0,0,NULL,NULL,NULL),(11,4,'10.80.10.53',0,0,0,NULL,NULL,NULL),(12,5,'128.171.80.81',0,0,0,NULL,NULL,NULL),(13,2,'128.171.80.81',0,0,0,NULL,NULL,NULL),(14,3,'128.171.80.81',0,0,0,NULL,NULL,NULL),(15,4,'128.171.80.81',0,0,0,NULL,NULL,NULL),(16,6,'128.171.80.81',0,0,0,NULL,NULL,NULL),(17,7,'128.171.80.81',0,0,0,NULL,NULL,NULL),(18,3,'128.171.84.17',0,0,0,NULL,NULL,NULL),(19,2,'128.171.84.17',1,0,0,'2016-07-08 23:51:12',NULL,NULL),(20,8,'128.171.84.17',0,0,0,NULL,NULL,NULL),(21,9,'128.171.84.17',0,0,0,NULL,NULL,NULL),(22,10,'128.171.84.17',0,0,0,NULL,NULL,NULL),(23,11,'128.171.84.17',0,0,0,NULL,NULL,NULL),(24,12,'128.171.84.17',0,0,0,NULL,NULL,NULL),(25,13,'128.171.84.17',0,0,0,NULL,NULL,NULL),(26,14,'128.171.84.17',0,0,0,NULL,NULL,NULL),(27,15,'128.171.84.17',0,0,0,NULL,NULL,NULL),(28,16,'128.171.84.17',0,0,0,NULL,NULL,NULL),(29,17,'128.171.84.17',0,0,0,NULL,NULL,NULL),(30,18,'128.171.84.17',0,0,0,NULL,NULL,NULL),(31,19,'128.171.84.17',0,0,0,NULL,NULL,NULL),(32,20,'128.171.84.17',0,0,0,NULL,NULL,NULL),(33,21,'128.171.84.17',0,0,0,NULL,NULL,NULL),(34,22,'128.171.84.17',0,0,0,NULL,NULL,NULL),(35,23,'128.171.84.17',0,0,0,NULL,NULL,NULL),(36,24,'10.80.10.98',0,0,0,NULL,NULL,NULL),(37,489,'10.80.10.98',0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `activation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jobtitle` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `employee_num` text COLLATE utf8_unicode_ci,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`)
) ENGINE=InnoDB AUTO_INCREMENT=490 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'albano@cfht.hawaii.edu','$2y$08$anSU2ORZsUaJkmg1R8aK0uUqoH.cW0yOw7UHeq.FJf.i3GXAc9Uu2','{\"admin\":1,\"user\":1,\"superuser\":1,\"reports\":1}',1,NULL,NULL,'2016-07-08 01:22:23','$2y$08$L61obh8KMymYudxfLEkKfODlOZYtjxjgHXR29/iHIe.pRE702x7uC',NULL,'Daryl','Albano','2016-07-01 23:48:39','2016-07-08 01:22:39','2016-07-08 01:22:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'albano','Generated on install',NULL),(2,'','$2y$08$6p9mZddpT61sOW7aFCSHIO/LoQhOVMLZgvAalSVdBz4JBwYn/2X2K','{\"superuser\":1}',1,NULL,NULL,'2016-07-08 22:53:57','$2y$08$tDIIqSueA4N55Z54EJD6QuHp7.wEFKFMuf3itVR8eru7OYKpWoVay',NULL,'Admin','snipeit','2016-07-06 20:49:48','2016-07-08 22:53:57',NULL,NULL,NULL,NULL,NULL,'','',NULL,'',NULL,'admin','',NULL),(3,'','$2y$08$1T7zl8Dqwf4huCaSbBkqsuWuTcpjafyNAmZKc6knoNIBzBxVG/MoS','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,'2016-07-08 22:52:29','$2y$08$bUGXLyrz1xODRojUA8JepOhO32Liz0xG4U5LUW62F9hig0dpLasce',NULL,'Daryl','Albano','2016-07-08 03:33:42','2016-07-09 03:27:40','2016-07-09 03:27:40',NULL,NULL,NULL,NULL,'','',NULL,'',NULL,'albano','Imported from LDAP',NULL),(4,'','$2y$08$T3Tzf902VLKrE9fJOQrY5.zQsrZhyjZPM66SDkNuvqmsxrwSG5hmW','{\"user\":1}',1,NULL,NULL,'2016-07-08 06:54:38','$2y$08$1sOQzRsMSHBCPVr7Jy3LMu9ukRrokzlJD7whMSWMbvdLstv5Hys/y',NULL,'','','2016-07-08 03:35:22','2016-07-08 22:56:13','2016-07-08 22:56:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'assetadmin','Imported from LDAP',NULL),(5,'','$2y$08$fuotRr3kyOjKnYVKapz4Mes.6qeSdmiH2aYs5RqjRTZfOO88LxlRu','{\"user\":1}',1,NULL,NULL,'2016-07-08 04:02:37','$2y$08$uIOur6C3mGNmBlqaUe8IeuvIW0qzG7vZK.5RkxXM/zrUJI1i.ErSW',NULL,'','','2016-07-08 04:02:36','2016-07-08 04:03:39','2016-07-08 04:03:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(6,'','$2y$08$PTXxB6FGpmLzVGSKqhVKoeAPlBTRBAKiT97.WtcUIAuMUDXBZU0E.','{\"user\":1}',1,NULL,NULL,'2016-07-08 06:53:25','$2y$08$RpfjqbMWGViK76v6f7GqP.nbuDoAqWaXp4GexJX88PkuHmIUdq49.',NULL,'','','2016-07-08 06:49:05','2016-07-08 06:55:10','2016-07-08 06:55:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(7,'','$2y$08$ZiQ1xSqtO8u6Ak73QIPqWuh2uaCvBdSgoPVVNlNvN5MrcLYY40wo6','{\"user\":1}',1,NULL,NULL,'2016-07-08 06:59:02','$2y$08$XP8TTFxwiVuoSQAjYsh37ez/zleCdx6h7wZk2qQmb8FhuhWcjQVjK',NULL,'','','2016-07-08 06:56:19','2016-07-08 22:56:17','2016-07-08 22:56:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(8,'','$2y$08$XdswWdbY28xlSCuObC4nBO.jxRJDik03FPQl3ZDssRDIy5AwpfWXe','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:26:16','$2y$08$KlNHZKrENZMkqjnOyUYXnuV2H1GBEBl4oSHvpL4hJTaZe3D3/ognu',NULL,'','','2016-07-08 23:26:16','2016-07-08 23:30:34','2016-07-08 23:30:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'assetadmin','Imported from LDAP',NULL),(9,'','$2y$08$PGrXTlEaPYtjGxJb9CRAOeBrrnlWRAC61BYX2Tigvq9.yQhW8l.NS','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:31:05','$2y$08$Xtp1egTnM8ZsDVmd9DkLFOMI2XfPBsa0y/HGFAgaR.Y88Ah.c5muS',NULL,'','','2016-07-08 23:31:05','2016-07-08 23:32:39','2016-07-08 23:32:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'albano','Imported from LDAP',NULL),(10,'','$2y$08$UygiL2JkMVXovV8sFJ1KyO8UFP8Y.GfgxTPb1AkE9vLuaiq1wQPK2','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:31:42','$2y$08$nx4XNfAvh0FsG4YXz7lPkuydVE/F/wZxtX7jqlUK570oOqGHKINbi',NULL,'','','2016-07-08 23:31:42','2016-07-08 23:32:42','2016-07-08 23:32:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'assetadmin','Imported from LDAP',NULL),(11,'','$2y$08$5zTvkwnOkACZudGFt8gM5ewbMQ0aGzTI319KDqOdhzssKs2/tPge.','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:31:58','$2y$08$Tzl1BSb4Z3fczGivhB8zeu/O1laHxmWmK5dpPqVL4bzpQROccXtAe',NULL,'','','2016-07-08 23:31:58','2016-07-08 23:32:45','2016-07-08 23:32:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(12,'','$2y$08$REnto9iYt5dK7g2ehdwv2OPuN82/LVLaUsTy/50AtOnlB6UOKsSmq','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:41:07','$2y$08$NASNmakSHn0AHfVes2TzDOw8Dc2PJOpOHYjQ1gTGuQ5PBakDRnMBG',NULL,'','','2016-07-08 23:41:07','2016-07-08 23:46:45','2016-07-08 23:46:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'albano','Imported from LDAP',NULL),(13,'','$2y$08$8xhF9ZvzP8cJgaBVojFNeOham0tV.DHVdYXpvesnZRqlYZxWdFnNO','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:45:10','$2y$08$BgYv1a8m9gLJ06VTpseEoeNnjB7zwp9FZMbEflshplFGC/cdWNxqu',NULL,'','','2016-07-08 23:41:23','2016-07-08 23:46:48','2016-07-08 23:46:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'assetadmin','Imported from LDAP',NULL),(14,'','$2y$08$0tNUBJAzIZvJlG4Cw5r1y.GKTODPUjtXcNHIyevQ6HRWUeRBjO9EW','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:47:37','$2y$08$5cZA36Uh0iqyeIjdzl1Ba.WYQj9sKZKVNrMVM9Eot6KObJ3p.SSvW',NULL,'','','2016-07-08 23:47:36','2016-07-08 23:48:04','2016-07-08 23:48:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'albano','Imported from LDAP',NULL),(15,'','$2y$08$CiofgtldG6jP9vu9AhInru6U0MkYzgiQSja.iIravwDhFbflIiOIm','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:47:51','$2y$08$Q4XSTRAOFlpyxf99XPjBw.V0hSCC8VqYKZGnois6POesYFjufk2xG',NULL,'','','2016-07-08 23:47:51','2016-07-08 23:48:06','2016-07-08 23:48:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(16,'','$2y$08$TWiXwRRlobiUb4Fc4a62nuUG1TjbdorW7Wv3t6m4T9BOS.NG8cTB2','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:50:48','$2y$08$IVzkt4PQFyxhRQNVHiLY7um7vlf96CQnETN8sCyB6SlId577tiyoK',NULL,'','','2016-07-08 23:50:47','2016-07-08 23:52:17','2016-07-08 23:52:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'albano','Imported from LDAP',NULL),(17,'','$2y$08$CcWRBt3AuzXjkEvZgEDNseEbMTXXW8uFCZThsf5kWtXxecu684vHu','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:51:02','$2y$08$7DQXvNn36JiAeAEB0elO9ulFu3qsWbIQkBx/1MW0aCxcIJCaDLSyy',NULL,'','','2016-07-08 23:51:02','2016-07-08 23:52:22','2016-07-08 23:52:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'assetadmin','Imported from LDAP',NULL),(18,'','$2y$08$F6wv5KnSt7Zk03MseH0VJu.lCmfnj4WMtLqm5TxJ..KW57gCkwA.i','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:51:19','$2y$08$t1Gwb92OMhg5DEzs7tGA7uDa8VdkitSaqmnLYzFj7FglPXhKp3CrS',NULL,'','','2016-07-08 23:51:19','2016-07-08 23:52:27','2016-07-08 23:52:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(19,'','$2y$08$kzQmeaJ1cJoghzGbBgixJuQDHmd9pmvHDR1z2cZSYloc6Af1WyoDi','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:56:16','$2y$08$nOcqdpuTogQM629HkpPO7evyiwSk2K9vS7f9JVnM8HC7R1RPblns.',NULL,'','','2016-07-08 23:56:16','2016-07-08 23:56:35','2016-07-08 23:56:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(20,'','$2y$08$GEcg5hukB9X1mCZPUZKMLepWkN9ATfLR.Sk2W7VkvVbRdWl8/6eCG','{\"user\":1}',1,NULL,NULL,'2016-07-08 23:56:52','$2y$08$Q2STT7uXZ1o45dCQ8EVgtuJ5DtO8xf06cEBMusTV5mzDe7ThYSaEy',NULL,'','','2016-07-08 23:56:51','2016-07-08 23:57:09','2016-07-08 23:57:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(21,'','$2y$08$Gvb8orvfZJNlcaSCLLFNXOjWRe6J3faARrBHdMqT7cSz3ffWKsFU.','{\"user\":1}',1,NULL,NULL,'2016-07-09 00:03:45','$2y$08$aunjstorJRa29K3fHDb1huTZo0LQ04IuS2vk9v./8k2SmlSxbxEoK',NULL,'','','2016-07-09 00:03:45','2016-07-09 00:05:09','2016-07-09 00:05:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(22,'','$2y$08$FjK1rnRGbhyCSY1EY7E70Ocmx.6Wxg4tL3tEdE24m.nzsqd3.iS2G','{\"user\":1}',1,NULL,NULL,'2016-07-09 00:03:56','$2y$08$o4b3qulksLZsrWeQYIHyn.F/3tWmYIZQHTdbD/8PUZdrmBkP6iPS2',NULL,'','','2016-07-09 00:03:56','2016-07-09 00:05:09','2016-07-09 00:05:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'albano','Imported from LDAP',NULL),(23,'','$2y$08$A7tFTHqooed92l0aC1q7GeFEE7Me1MKnnA/lJOIYxPphBV1yui8NW','{\"user\":1}',1,NULL,NULL,'2016-07-09 00:04:26','$2y$08$UYmQm30YIRrtJLhMwoa8iORpTZDlPYLmutyZm/d1YT3VsMuHJJzQS',NULL,'','','2016-07-09 00:04:26','2016-07-09 00:05:09','2016-07-09 00:05:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'assetadmin','Imported from LDAP',NULL),(24,'','$2y$08$wbzRz1yHXY7EwppRaF2I5OId6kZdjO7T6KKOb5FxQtrZnw9WjdQSO','{\"user\":1}',1,NULL,NULL,'2016-07-09 02:07:06','$2y$08$dt57zle4UwsumTU5A7KG0.yiMUU6MpndH5r2IuQtl644kLihgtwGu',NULL,'','','2016-07-09 02:07:06','2016-07-09 02:07:17','2016-07-09 02:07:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL),(25,'lwells@cfht.hawaii.edu','$2y$08$RtDfAbPCnXziPI586WhBdupdGFYsQD4DYhEWHUccr9cClgdd.iHl2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Lisa','Wells','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lwells','Imported from LDAP',NULL),(26,'kuotiong@cfht.hawaii.edu','$2y$08$dr03pCxUMxjsbetfHKkykOZ79ZSCzBAtHL1O.X4x5wE2NtQlH7VSS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Blaise','C. Kuotiong','0000-00-00 00:00:00','2016-07-09 03:23:08',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kuotiong','Imported from LDAP',NULL),(27,'postgres@cfht.hawaii.edu','$2y$08$V1fhsXJAC6PORkcNCEZSpuOJ2uxweSnk.T86wCMJy6ZNX.4CiExUa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Postgres','User','0000-00-00 00:00:00','2016-07-09 03:23:38',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'postgres','Imported from LDAP',NULL),(28,'geckoeev@cfht.hawaii.edu','$2y$08$MMD2uCbulOcwT5tIto86r.7qloXHl5Mr66SmJV.jMoNVQTIWCwMEi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'El','Gecko with eev','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'geckoeev','Imported from LDAP',NULL),(29,'qsouser@cfht.hawaii.edu','$2y$08$blqL8RkhjNY9NXRgIKnyi.UncDMrumh9mHRdabvj64RILVlbXNgKC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'QSO','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'qsouser','Imported from LDAP',NULL),(30,'healey@cfht.hawaii.edu','$2y$08$0v0M2WNiFILtEVnw17m5o.Su/WEuEnM3DWovnhgVY7hFr1VNyijpe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SueAnn','Healey','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'healey','Imported from LDAP',NULL),(31,'bauman@cfht.hawaii.edu','$2y$08$YwqHY6TUwsdNPkmLtxZpReTHCqYMkzhEuSW2wHAjPp78amzFKmXyW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Steve','Bauman','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bauman','Imported from LDAP',NULL),(32,'sl2s@cfht.hawaii.edu','$2y$08$ApRjZBoU2KYhypN6hMhxL.zFDh33CRXG0eWSdZiL5uP3ypmUWnL06','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'sl2s','visitor acocunt','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sl2s','Imported from LDAP',NULL),(33,'malo@cfht.hawaii.edu','$2y$08$fnXUXGl02XMCgBSfUjSNwuaHpe7Bf847a9yWuqWaCpG2gCz0wRRlG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Lison','Malo','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'malo','Imported from LDAP',NULL),(34,'ptolemy1@cfht.hawaii.edu','$2y$08$W9qEI0InaIIVEtXCcABRKON38K9U9tVBaiBIgWJFsAzcvV5O4r9T.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'I\'iwi','user','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ptolemy1','Imported from LDAP',NULL),(35,'fundware@cfht.hawaii.edu','$2y$08$gv2iipBGCQLFdV4WWBVl9upZuJZeKNPrJ3Q1JrZ9XtCXffAw8vFXi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Fundware','User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fundware','Imported from LDAP',NULL),(36,'shapiro@cfht.hawaii.edu','$2y$08$XRuZsiNWMfIKq0aC4lBLVek2art7s2WAJfYPAc934A70iUgBt3/Sy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Joshua','Nathan Shapiro','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'shapiro','Imported from LDAP',NULL),(37,'knight@cfht.hawaii.edu','$2y$08$Vp0OxZWFmFQqD6lzwBJzrOoOMNUeAzablvzhqeRfP2.Aoda6cYUYy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Wiley','Knight','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'knight','Imported from LDAP',NULL),(38,'aobrtc@cfht.hawaii.edu','$2y$08$nlu0uIlqZGEoQoBtc9Q5h.qMdjKtlPnv1fyz6v8yhM1L48JvL.3Q.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'AOB','RTC files account','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'aobrtc','Imported from LDAP',NULL),(39,'usher@cfht.hawaii.edu','$2y$08$SvpQoKg1YR4GddmaowcaGOhIYET3J2YjzxmQFfGFjcnBz7.tp9ypi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Chris','Usher','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'usher','Imported from LDAP',NULL),(40,'nowak@cfht.hawaii.edu','$2y$08$Ztv78rKe2oKkZSCvyJqKwOElXBl8RdN/yRonlXWbdF5hHnKt4v.na','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mathias','Nowak','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'nowak','Imported from LDAP',NULL),(41,'deti@cfht.hawaii.edu','$2y$08$qxmq5pVgZQogkzObjaHky.B3MKco1NjmfuYeMw2iVvEjSyL7j9StG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'DetI','General Use','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'deti','Imported from LDAP',NULL),(42,'sarchive@cfht.hawaii.edu','$2y$08$CtGwynr2B87PAXZF9HoGp.USJEjPfOZ28ObEpzbs5pORqVwGI10Kq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','archive user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sarchive','Imported from LDAP',NULL),(43,'szarlan@cfht.hawaii.edu','$2y$08$CHercl4BA8jdMdt0Hm8UHufcztfNBnYJhY9Nu6OSQrBCFzXCZ/BpS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Todd','Szarlan','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'szarlan','Imported from LDAP',NULL),(44,'savalle@cfht.hawaii.edu','$2y$08$jbVJGFXmmAqRz6UHT9okCePmJ6G0WCB3RQzuBJ.8IPrhCe77fx4Ga','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Renaud','Savalle','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'savalle','Imported from LDAP',NULL),(45,'bastien@cfht.hawaii.edu','$2y$08$wvZiljcDcxQrwtbLloiT2e08dTEsZtT9AIcdswJWUVAkfn2al/WPG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Pierre Bastien','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bastien','Imported from LDAP',NULL),(46,'warren@cfht.hawaii.edu','$2y$08$fR1YAtaioxjwRr37vhE5IuzR.aJ9wHmspLFZ9as9v36wAjL0G1T3y','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'DeeDee','Warren','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'warren','Imported from LDAP',NULL),(47,'rouan@cfht.hawaii.edu','$2y$08$Jf4OM252J3R87dMZz05lkO2fiamkcIaG4iK.YLrGtTCha7bs28f2S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Daniel','Rouan','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rouan','Imported from LDAP',NULL),(48,'isis@cfht.hawaii.edu','$2y$08$XnzN1ZSWxvHcpq1z9ReI0.Vi2WrX.ONZ2svitPXiabB.jTwFOFnAG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'ISIS','ISIS','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'isis','Imported from LDAP',NULL),(49,'celtsite2@cfht.hawaii.edu','$2y$08$eM0fqF3GJoy5wu42PwCnduw6mxcWy8.L.jOBerL6ulNHzAwAajFzu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Celtsite','DIMM user 2','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'celtsite2','Imported from LDAP',NULL),(50,'sarchnie@cfht.hawaii.edu','$2y$08$NbHrXjs9YIrH2Wvr8wcSUOEqWIaFOfnYN7Z4bP5Lf2vB4sEt1U8vm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','archive user on niele','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sarchnie','Imported from LDAP',NULL),(51,'ptolemy2@cfht.hawaii.edu','$2y$08$Gex0LB4TFhOOSbAj7ni7o.YFu4NqG4rIw0RSFAj0LuKaiECeT4B5G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Elixir','user for MP36','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ptolemy2','Imported from LDAP',NULL),(52,'hamilton@cfht.hawaii.edu','$2y$08$0Cf7gBXvJk3RF5WM5X2Hj.WGQ4IKBt2f4S22OTmO4v6wQSuH.21/.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','Hamilton','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hamilton','Imported from LDAP',NULL),(53,'rodgers@cfht.hawaii.edu','$2y$08$eENnZ95LTUTT6E7DK50At.jr.KnUpNcaYzYTSNTKakFnuWr7gJ/oq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jane','Rodgers','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rodgers','Imported from LDAP',NULL),(54,'tully@cfht.hawaii.edu','$2y$08$8IWYU4N3BI0mDbeLLmgkRetKx1vt3FJsFgYlOOUzsWKbGcSH9Jo3W','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Brent Tully','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tully','Imported from LDAP',NULL),(55,'sarah@cfht.hawaii.edu','$2y$08$cDwMcBqlxZXhLHmwGi1r7ezmgGf/8hu..y/O/zIhVK7jjGlUBsCWm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sarah','Gajadhar','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sarah','Imported from LDAP',NULL),(56,'polak@cfht.hawaii.edu','$2y$08$JZSiy0y81LmWZaNSkDpcE.qL1bunf6l7Q6JZ91cR9.0mNg9iDjHG.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Lucia','Polak','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'polak','Imported from LDAP',NULL),(57,'yag@cfht.hawaii.edu','$2y$08$u3z8tUGdDptsiKfXbIumeeQfNHAu7Kv3N/PgVi0DvRet2VLqj2G.u','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'YAG','Laser Operator','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'yag','Imported from LDAP',NULL),(58,'goo@cfht.hawaii.edu','$2y$08$YKQl1hvW5jbo3oNyvDOizuPnFeKjLCeGPpaSSkEK0eCDJaTGo8WWe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Damon','Goo','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'goo','Imported from LDAP',NULL),(59,'nothing@cfht.hawaii.edu','$2y$08$IgrR9eBrL12DchzfJdZXuuu.YMjiVo3lQ2qTcPfwV31uHADE8Nynm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SSH','Tunnel Account','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'nothing','Imported from LDAP',NULL),(60,'gaudet@cfht.hawaii.edu','$2y$08$KUYqx9us82fmrpK1sl3URebfn2aphmukR2VNjGPypYmwP.E9dHOqG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Severin','Gaudet from CADC','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gaudet','Imported from LDAP',NULL),(61,'gregh@cfht.hawaii.edu','$2y$08$Jf2Y6yg9niQWxbaDjtgJ9u8CTFtJJfYQ0CcSytl5VqxKlvjE1vWHq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Gregory','Higginson','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gregh','Imported from LDAP',NULL),(62,'evans@cfht.hawaii.edu','$2y$08$V7zeLWdIfDb98HeCIUw6x.i6r5Z87U1EJoHZ1V9.Jc5c9qQvj80bC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Linda','Evans','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'evans','Imported from LDAP',NULL),(63,'tcs@cfht.hawaii.edu','$2y$08$nQ2YdguKdCWZJCoCs1aby.KWzylaWbqU7YXDVp6EPzMYgB2YUxfZe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TCS','VxWorks User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tcs','Imported from LDAP',NULL),(64,'doh@cfht.hawaii.edu','$2y$08$xIrRuTDLqKmDOTMruvR4jOs1rJWVi4Ricn0ioNyAcV1tdeoog.98q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bill','Cruise - Doh','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'doh','Imported from LDAP',NULL),(65,'murowinski@cfht.hawaii.edu','$2y$08$42gfQG89PNAJSMqR5hpYZ.7S3h./bOF0pJ.VnmeN8GpU3QVu7EOFq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Richard','Murowinski','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'murowinski','Imported from LDAP',NULL),(66,'jonathan@cfht.hawaii.edu','$2y$08$QKzZPm9bcrUv93jSE4wjoeRgPSiS36zxYYCsGzJH3iCWxw6Yh2zp.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jonathan','Hutchinson','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jonathan','Imported from LDAP',NULL),(67,'pythias@cfht.hawaii.edu','$2y$08$Qv8kkOc0x2T98avnEsKVGe2jT3bSLVGM7kn/Wv4S/UvHA9Wx9WO36','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pythias','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'pythias','Imported from LDAP',NULL),(68,'hickman@cfht.hawaii.edu','$2y$08$WGw6rhuhdBMJIwGqbCTuUOYnpUqEi2GOdC7zbbQkXGk2EE6V2Z3IW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Coleen','Hickman','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hickman','Imported from LDAP',NULL),(69,'tarnas@cfht.hawaii.edu','$2y$08$ZzJaYxUajSutkcLcEgPCN.bKlEAC0MmAr/d8UwrqcjRzn8Ur1S97u','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jesse','Tarnas','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tarnas','Imported from LDAP',NULL),(70,'mazure@cfht.hawaii.edu','$2y$08$QolcQwzYrIs3crFQ25DMperxvf7QCetXr397iwgOJH3/9QPZm0BGy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Alain','Mazure','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mazure','Imported from LDAP',NULL),(71,'patep@cfht.hawaii.edu','$2y$08$sKXArr4CcKY2XFyI3hAQVevUqVR39ITbtusIFKurJAcqkZnqUUnd6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pat','Perez','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'patep','Imported from LDAP',NULL),(72,'jones@cfht.hawaii.edu','$2y$08$D407vcFMUD2qLg6u4lPKTeOaL0npAj98fyuckgpOcg2lmGN8zVZYK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Windell','Jones','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jones','Imported from LDAP',NULL),(73,'alien@cfht.hawaii.edu','$2y$08$e6cPeAs8bAkqhRE8UMDFGueqwpuXWYzUM2GoWUFaI/f2UYyZNUGOu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Visiting','Data Acquisition','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'alien','Imported from LDAP',NULL),(74,'spb@cfht.hawaii.edu','$2y$08$pVPNjQsodYtOm9CPdKRRyu2Q3haBgoX1pumYSq5PWLPruDfM.bCuK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Skyprobe','Skyprobe','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'spb','Imported from LDAP',NULL),(75,'desrochers@cfht.hawaii.edu','$2y$08$Uy5Igd7flaGorcjMb90dceiFUjXuVCOXEvJXLYvvFxc3Bo/Yo2K4C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Marie-Eve','Desrochers','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'desrochers','Imported from LDAP',NULL),(76,'megamail@cfht.hawaii.edu','$2y$08$yRJO1Ctc9xmRozTTWPul3OXkMtkHxJbgcWIv1IWLgJ9gsh5KOZYZO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Megacam','Mail','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'megamail','Imported from LDAP',NULL),(77,'selliez@cfht.hawaii.edu','$2y$08$EE90mchx2qiJMst86qOrUOxcV4fbpo3lKs2jMJSMxuPDBkYsPHfVy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Laura','Selliez','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'selliez','Imported from LDAP',NULL),(78,'redeyen@cfht.hawaii.edu','$2y$08$zUQhZmVt8y7MCdBTDbebiO446B.PtTxUbVphtaZo1rqS8s/RYhARe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Narrow','Infrared Camera','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'redeyen','Imported from LDAP',NULL),(79,'gabbert@cfht.hawaii.edu','$2y$08$zCQKjQNQAmvuoGxJb445guYtQjdJM..DJacjgISXB5TJJPfop92pW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Fischer','Gabbert','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gabbert','Imported from LDAP',NULL),(80,'demomfp@cfht.hawaii.edu','$2y$08$OLItENIm5eFjRtE2gfD6sOTSZfWgLdH6s//gZa1udXu.uxGTX0wue','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOSFP-DEMO','MOSFP-DEMO','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'demomfp','Imported from LDAP',NULL),(81,'lenoir@cfht.hawaii.edu','$2y$08$sKGVvXsUbKQIckuzPUSwVOOu0eN8UDbBzDDKLpT6zpWW/pojO83.G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Benjamin','Lenoir','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lenoir','Imported from LDAP',NULL),(82,'cfhtir@cfht.hawaii.edu','$2y$08$TEqzPXhqsgoqsElyMfK40.47ox1BPC7yTTUyXsiYpLF.luvROb.Ji','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHT','IR','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cfhtir','Imported from LDAP',NULL),(83,'bryson@cfht.hawaii.edu','$2y$08$3ljgFthsHIdiP3Cf7ICfeOGDYQ5VGqJINfirUv2rqc1nw3aYlbDSm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Liz','Bryson','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bryson','Imported from LDAP',NULL),(84,'jtest@cfht.hawaii.edu','$2y$08$irPlF8y8dXH0YEGYD7psy.Svil8/LRc0wbAQOjB9DhHM6SNH/AN/2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'for','Jim\'s testing on aa','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jtest','Imported from LDAP',NULL),(85,'jsick@cfht.hawaii.edu','$2y$08$EaLi38lZGCtMxNpQ5c0iLOY.rzeI41fjCHJS1s6zLmp5lh8VLS3fO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jonathan','Sick','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jsick','Imported from LDAP',NULL),(86,'john@cfht.hawaii.edu','$2y$08$dgYlWz2s2CcRuxIg07bJ9uewiZtc57jLM3..g65vxxW7xR91Jlgrm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','Kerr','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'john','Imported from LDAP',NULL),(87,'yue@cfht.hawaii.edu','$2y$08$lUchkj4HMffkCErjN24hQ.Mei8k5QEHeI8twFK.dKQTPaqdzg2pVi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Yue','Dong','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'yue','Imported from LDAP',NULL),(88,'tcsivsim@cfht.hawaii.edu','$2y$08$zUerAkUSQWu1upg3E6bsqOZNSLofoq6xt.H.W6nYnElHyelzYGjCO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TCSIV','simulator','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tcsivsim','Imported from LDAP',NULL),(89,'barrick@cfht.hawaii.edu','$2y$08$Rw38PYuk03pdk0a3D9GHV.bj6tgKPm.3n4LWFIYjhAfGfgS84dgPi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Gregory','Barrick','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'barrick','Imported from LDAP',NULL),(90,'riopel@cfht.hawaii.edu','$2y$08$KIEMfzm1kNUyIwbkKGONVeBkPFsnQoOq.uxm5xMRLk8iL9vKq/2lK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Martin','Riopel','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'riopel','Imported from LDAP',NULL),(91,'monica@cfht.hawaii.edu','$2y$08$zIjg70kXXha0USAMPsFG6OrRgBO2QMKBk7VK4XnrBxtCoh4t7uAAm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Monica','Visiting Instrument','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'monica','Imported from LDAP',NULL),(92,'cruise@cfht.hawaii.edu','$2y$08$M71bTejbQssE1ZxJqKOjW.2ct7e2FQkt1efbGhbRQN3XaDdIg2LVO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bill','Cruise','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cruise','Imported from LDAP',NULL),(93,'tbeck@cfht.hawaii.edu','$2y$08$khH2IJWmeoBi80sd9JUpDu3cXU2ghA2s8zzgPLN6RKMjFHH4Y2XRK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Thomas','Beck','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tbeck','Imported from LDAP',NULL),(94,'isani@cfht.hawaii.edu','$2y$08$02VDkBhK75mTrJG8byCmPeG01rbdJTDpShnRCCSc22UEC8uFGXS4W','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sidik','Isani','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'isani','Imported from LDAP',NULL),(95,'10mic@cfht.hawaii.edu','$2y$08$Ta8HK0rUA4dBGOQNy0gNxOES5iGi.wBYG2j70tYVrx4Sq0MkBQY5C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'10','Micron Camera','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'10mic','Imported from LDAP',NULL),(96,'mary@cfht.hawaii.edu','$2y$08$31ByEaxJhQGIfYnr951cPeKuBPTi9riAhyEnGcpTRGy1hzhiUCTSC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mary','Beth Laychak','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mary','Imported from LDAP',NULL),(97,'rjw@cfht.hawaii.edu','$2y$08$irz27uRXVMPzn0OJCNb1Fukc8Yg0LxdIbK.CLH5AxYPcncSc1L.uK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Richard','Wainscoat','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rjw','Imported from LDAP',NULL),(98,'sqsouser@cfht.hawaii.edu','$2y$08$8Jim2R3eTT7y7erf4Za4kOkS2sYv0sdNhFGdBEcfbVSnHJgQlS.SW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'QSO','user at the summit','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sqsouser','Imported from LDAP',NULL),(99,'espamail@cfht.hawaii.edu','$2y$08$kpHF14rcPyssmHe8X24pSu/f0R7H/cGnXk/LJ4/lcCW49bCpsOXMe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Espadons','Mail','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'espamail','Imported from LDAP',NULL),(100,'demosis@cfht.hawaii.edu','$2y$08$0T0tCej5pUcZYi16sYDeq.H6GKULV.CAYgCHBTp8Yy7e6ydLjK67G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SISDEMO','SISDEMO','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'demosis','Imported from LDAP',NULL),(101,'tcsivw@cfht.hawaii.edu','$2y$08$TqFH8pu1HRKxUgCpPYJbxOZwBPZJ8o5Eo/rbM0rUrhvNsXfXXQT2S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TCSIV','OAP Waimea','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tcsivw','Imported from LDAP',NULL),(102,'ismael@cfht.hawaii.edu','$2y$08$AHMrH2dbgBmYGeMdW8ovsez4p.VBz2K9eITYV/Tcc1cS8fxbBaq72','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ismael','Moumen','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ismael','Imported from LDAP',NULL),(103,'tonry@cfht.hawaii.edu','$2y$08$CCOjDprdmORsI2k9xQv6AO4B0m7BhbWKNefnAHae5TMsE6lDAHEUq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','Tonry','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tonry','Imported from LDAP',NULL),(104,'mosargus@cfht.hawaii.edu','$2y$08$aEhci69kqe3kalzCq0bAQu17aHT/MjjezbiIbRbLtwuxGF15W3VkS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOS,','Argus','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mosargus','Imported from LDAP',NULL),(105,'espadons@cfht.hawaii.edu','$2y$08$y3UABWGQpvbnFOrhKz3ipOQxXNHa4tuvLTaM8OrLyk.5ZKZSW15qW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Espadons','user','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'espadons','Imported from LDAP',NULL),(106,'atapattu@cfht.hawaii.edu','$2y$08$OFi5smTwY1RZ39hMfjd2HenT/lOU7FNu5MbMByRvcmN.oxiMFv54e','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Rohendra','Atapattu','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'atapattu','Imported from LDAP',NULL),(107,'millard@cfht.hawaii.edu','$2y$08$oG9y0X8hncCwGIOKFq7dwuWuenAtHJAGvXk.Ki/FtMeD0TV486.si','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Larry','Millard','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'millard','Imported from LDAP',NULL),(108,'luciani@cfht.hawaii.edu','$2y$08$N4qRnNwWdUK9ac7PiP1qUeKfBAc13t9HOFHGaeROAmhymYqot1ilO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'William','Luciani','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'luciani','Imported from LDAP',NULL),(109,'loggerw@cfht.hawaii.edu','$2y$08$9Kn63xxTTC0ZAFIt2Yn4QeJ.3y7kgKqkxsV5SfS5skfiTRoKa6vQ.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Data','Logger Project in Waimea','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'loggerw','Imported from LDAP',NULL),(110,'wircam@cfht.hawaii.edu','$2y$08$cdUqBIHS6gy2UKsYz4hRBuPQrxNFmO8B1QSqPeKoc4wHIjL.CC4FW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'WIRCam','user','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wircam','Imported from LDAP',NULL),(111,'simons@cfht.hawaii.edu','$2y$08$eS8Ihd6f4gXmRchSAO2BguZKjwVesfOaI7lO2bIsMTHxZ5tJa6PSm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Doug','Simons','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'simons','Imported from LDAP',NULL),(112,'bezuit@cfht.hawaii.edu','$2y$08$tl31HCA0vfGyeGCtKMNzpuoFhpGvhYIG2aMm9.tfL8WUiWoU2xH6m','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Jean-Luc Bezuit','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bezuit','Imported from LDAP',NULL),(113,'wceng@cfht.hawaii.edu','$2y$08$72N1cf5b9GAsdIOPCrYAjOEg3zPZJ3q45GHmyg7cIswttMLIBzzHG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'WIRCam','engineering user','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wceng','Imported from LDAP',NULL),(114,'dep@cfht.hawaii.edu','$2y$08$hKnevPSiPOrRB7L3zk5IN.oem6/jjqLICBL7IGXWD0yVzUn7FzxP.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Dome','Environment Project','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dep','Imported from LDAP',NULL),(115,'yu@cfht.hawaii.edu','$2y$08$aV4HY9dgkTY9c07P4DMi1ug.KjqlKzcE2XMKux7.iOMrtM16sf00i','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jack','Yu','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'yu','Imported from LDAP',NULL),(116,'mitchell@cfht.hawaii.edu','$2y$08$wV84o6jy871mpl4dlJ3kqeK4z2pKmDNnMvyXyl4gKTp1U1pKLODAO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','George Mitchell','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mitchell','Imported from LDAP',NULL),(117,'emsellem@cfht.hawaii.edu','$2y$08$0o2YDZbBTevrvGYN8I6B5e//hN0RMLcip7gxGgJrcv50M3J6aDXUW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Eric Emsellem','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'emsellem','Imported from LDAP',NULL),(118,'musicos@cfht.hawaii.edu','$2y$08$ikzTwdlLrDUIpK4o9JhJge/8x11tht89fVaR.Ql0z6DP.UX1yQjpi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MUSICOS','visitor','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'musicos','Imported from LDAP',NULL),(119,'esparre@cfht.hawaii.edu','$2y$08$BTYN2gvyuQja5p5cafmVueP7hpZ2FXB4kI.mAvlAoTNnA5rAegwYG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Eric','Esparre','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'esparre','Imported from LDAP',NULL),(120,'agdeppa@cfht.hawaii.edu','$2y$08$ejcPvIH5jBRMqCo7jImTMetAU.Idisz3Toga/rREXoXqOLIYEOkaa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jay','Agdeppa','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'agdeppa','Imported from LDAP',NULL),(121,'sndice@cfht.hawaii.edu','$2y$08$e5ICXCfqT9dremq3Hiua9uqhvGgINVFokufldhBSh2zjyXAk80NZ.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SNDICE','SNDICE','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sndice','Imported from LDAP',NULL),(122,'marlin@cfht.hawaii.edu','$2y$08$zzv6QDSq0Q4AnRZNPRd3vOQA6YAdoEsOsuWe8lGGFdt8/qn.g8Opi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Marlin','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'marlin','Imported from LDAP',NULL),(123,'manset@cfht.hawaii.edu','$2y$08$WwvbqEK2xD9dyAGmOYsKge0CYjIBZ/dlHd0naUAyZBHkWywLCdKyy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Nadine','Manset','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'manset','Imported from LDAP',NULL),(124,'lilly@cfht.hawaii.edu','$2y$08$xMDnwdZNPXKM91IMZxeD0u/Ny4rCBmNtjsBlai1t7FepdCYUlPJHq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Simon','Lilly','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lilly','Imported from LDAP',NULL),(125,'aybu@cfht.hawaii.edu','$2y$08$1K8hBWjXP6kyNdDlGzxbgegBsqMoAABUINHia.Cn3JM5eUk2Hnvc2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'An-Yi','Bu','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'aybu','Imported from LDAP',NULL),(126,'wnr@cfht.hawaii.edu','$2y$08$ul7WaGHYMUU61w2dtnBZFOTyiHEtfI8IOmQqpIAAm83lbr04.sPLi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'William','Rambold (daprog)','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wnr','Imported from LDAP',NULL),(127,'kho@cfht.hawaii.edu','$2y$08$GTRIb5dZO2okcHVub0ukmO1ZAmB2TVSiDXoIhRD3sxJvstHZS/ZzS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Kevin','Ho','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kho','Imported from LDAP',NULL),(128,'mcconnachie@cfht.hawaii.edu','$2y$08$0S7atLUgx1eOKF0QBc7CDu3ESz7xEY0nM0rrpABAbOEA/0VsBQUsq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Alan','McConnachie','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mcconnachie','Imported from LDAP',NULL),(129,'terapix@cfht.hawaii.edu','$2y$08$s86WGToWP5npVyCV2goVi.ZwQ4Xl1jM07XagF3mBfgw9pX3XWPXcO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Terapix','Terapix','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'terapix','Imported from LDAP',NULL),(130,'coreys@cfht.hawaii.edu','$2y$08$F4QTLOBXxRM8G3YP6KfMze6zmxQ2ETnxZtTCMDKtQ/Ful.ZvOcoGW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Corey','Scholefield','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'coreys','Imported from LDAP',NULL),(131,'smpro@cfht.hawaii.edu','$2y$08$r0rxcIUjGqp2UKBXr7QpZ.fqMp6Cy4Yz5piKRDxnBG2jXc3mFBSoW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SMPro','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'smpro','Imported from LDAP',NULL),(132,'olsen@cfht.hawaii.edu','$2y$08$wanXXkASzasaAKSQ1S08Y.z9/0AHKgNROXDPTpX.oJKbTk0VuSgvm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Larry','Olsen','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'olsen','Imported from LDAP',NULL),(133,'babas@cfht.hawaii.edu','$2y$08$Gon2UYuiFHmXf3K9AI4NXeMCjHi9Hsga9iEBYL4MCvza6MzJwrjLa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ferdinand','Babas','0000-00-00 00:00:00','2016-07-09 03:23:58',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'babas','Imported from LDAP',NULL),(134,'bear@cfht.hawaii.edu','$2y$08$dVYsS1zXmtqiOk7S650ZLOjkDuYM9YHUxa3qv4.uz1Nl5YizdoMZi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bear','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bear','Imported from LDAP',NULL),(135,'oas@cfht.hawaii.edu','$2y$08$5OYfHibyCZJEbs9u7DEJHO9DeWu9eqBbqgPbvkyI0/qcHniAnIEX6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Observing','Assistant','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'oas','Imported from LDAP',NULL),(136,'sarchnoi@cfht.hawaii.edu','$2y$08$isA6v6ZT8zBKDYfdggdJ7uTfIO3HTuIHbFR0rgRvXuYXmJahd33Nq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','archive user on noii','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sarchnoi','Imported from LDAP',NULL),(137,'stevens@cfht.hawaii.edu','$2y$08$GmUA90WNYGtMAo1UMteI4um.WG3Ac/max7rbstPbbS1g4OO6dB0RW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mercedes','Stevens','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'stevens','Imported from LDAP',NULL),(138,'peretto@cfht.hawaii.edu','$2y$08$xwtSjqcxaPgSuAGQCnlFY.fS9zseqhPI4zyBirKEDn8H8E2V7AZFK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Peretto','Nicolas','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'peretto','Imported from LDAP',NULL),(139,'mcgehee@cfht.hawaii.edu','$2y$08$yH9gt1KqVUmrY7xM9wyeD.W5PGVOSHCkqFLv0XZaAU7t7ZFtxbn82','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Peregrine','McGehee','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mcgehee','Imported from LDAP',NULL),(140,'cadcarc@cfht.hawaii.edu','$2y$08$JHehsMuFtOa5VONFRT9dIui2eZudEy4vHsCRotuCFjT4GHsBkS/6a','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CADC','DHS User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cadcarc','Imported from LDAP',NULL),(141,'wdhao@cfht.hawaii.edu','$2y$08$a3srX9xNcFoPjSL6kFg6n.z2fifsUkU3fTYbbuwIn0YgZDgPMQ.6S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Wei-Da','Hao','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wdhao','Imported from LDAP',NULL),(142,'macy@cfht.hawaii.edu','$2y$08$wClNa2oU8VS8WGqhiXxb5OBhvRxaadMTXcrT0.n23kkzowCcLsH5m','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Dean','Macy','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'macy','Imported from LDAP',NULL),(143,'kim@cfht.hawaii.edu','$2y$08$aS7r5ObEiKIHIL3oh8BM2OCpq82ff4DoVG3d4jUag8W0Zwhz.F.UG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sam','Kim, intern','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kim','Imported from LDAP',NULL),(144,'rambold@cfht.hawaii.edu','$2y$08$6pJiwV1RDoc4nxkT41wRa.Ag89laA.NC8yu88z7idFZVccARj4Xom','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'William','Rambold','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rambold','Imported from LDAP',NULL),(145,'prioul@cfht.hawaii.edu','$2y$08$RW7T6rToAPDFEtyafzHQreug/FMNCbZDgF1RibrEG7M7/PyDS0k9S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pierre','Pierre','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'prioul','Imported from LDAP',NULL),(146,'seuno@cfht.hawaii.edu','$2y$08$GtuFi5c1HLqJObfwaRveNuNpdIorH9LEVym57rbDYX/lpxx7LZc92','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User on noii','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seuno','Imported from LDAP',NULL),(147,'seuna@cfht.hawaii.edu','$2y$08$dN256b6YhpXbWxjJHQkTluetNPx2r8LgB3k8nrrObFnyfMJSZhzem','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User on nai','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seuna','Imported from LDAP',NULL),(148,'grant@cfht.hawaii.edu','$2y$08$lIDo96A9a54QMQGA5cSVm.Mkwr7IwfLnGCEzgi3EE4OvPEsvzNseq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Grant','Matsushige','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'grant','Imported from LDAP',NULL),(149,'fts@cfht.hawaii.edu','$2y$08$gxg0S21pkrAy7z4YBFI3t.v3Ug5Ay4hEh5lszg3HxVL/GlAKq.1.u','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'FTS','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fts','Imported from LDAP',NULL),(150,'cf4@cfht.hawaii.edu','$2y$08$b8WLyKrBOXPBjHqhS6ivxuHEUD5AXpgE9LpYYHX8S4tadDKtiiJ/G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Coude','f/4 CCD','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cf4','Imported from LDAP',NULL),(151,'herzberg@cfht.hawaii.edu','$2y$08$thUjBOEwPSA35g0hFVH59OkOH8rKPqmD9bsJHVVh.ojm7nNOypCAu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Herzberg','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'herzberg','Imported from LDAP',NULL),(152,'tannock@cfht.hawaii.edu','$2y$08$C3K1Hjf7kA3lbQ4SNMGfv.5kIlPTW8jNHcNP0MZkoZQ4OP0i8ckcK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Megan','Tannock','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tannock','Imported from LDAP',NULL),(153,'emartin@cfht.hawaii.edu','$2y$08$BaQXLbrn9i0GnHro3k7qy.rqTPrc0KrgRBuPe/kt6f8Bq6jGtOAOm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Eduardo Martin','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'emartin','Imported from LDAP',NULL),(154,'sybase@cfht.hawaii.edu','$2y$08$nDObocSeAzUvDi0geCrFnOQEEGfp/L5NEwZJc8XpwjAlS0vz9Mo2K','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sybase','User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sybase','Imported from LDAP',NULL),(155,'kezwer@cfht.hawaii.edu','$2y$08$DmpQeuA8Y9g8DoL0u4078.SInxPlOhRzX5bzqZxgHfybIoLDOoNIS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jason','Kezwer','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kezwer','Imported from LDAP',NULL),(156,'baril@cfht.hawaii.edu','$2y$08$UPzxdW6QDKbt7pK9m2CgfOgjAjvlsao5YDWuY7vL56rcwIAXd3HHG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Marc','Baril','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'baril','Imported from LDAP',NULL),(157,'look@cfht.hawaii.edu','$2y$08$T2Mh1YERUQtyZU39hyUDFenQcPEqnRK6FT1dfsrjI.f95QCSkLIeW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ivan','Look','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'look','Imported from LDAP',NULL),(158,'jmcd@cfht.hawaii.edu','$2y$08$D1koghnhT5ouHRWbAqZas.YuVa.rbWTRSEKGCuxFJ5r.e9K1EmOsq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','McDonald','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jmcd','Imported from LDAP',NULL),(159,'ptolemy5@cfht.hawaii.edu','$2y$08$4moz8LyHlEaUGJJbbI52kOC8dufONK9K7PI.HdTkRO1Bnc//2d4U2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ptolemy5','User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ptolemy5','Imported from LDAP',NULL),(160,'ptolemy4@cfht.hawaii.edu','$2y$08$vW41I5NzVYSNa1Bfmpv3w.YysPGOU8hTJVEWaFos5GnYYAtlTl2Fq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Elixir','User for MP40','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ptolemy4','Imported from LDAP',NULL),(161,'draginda@cfht.hawaii.edu','$2y$08$ubC4Hb1dXPcgF2df3Vi9VuRmnzSSiBLyAxoXzhlYALAEwTgU31/tq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Adam','Draginda','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'draginda','Imported from LDAP',NULL),(162,'wwwmail@cfht.hawaii.edu','$2y$08$lawINT9IyuvP8WDpdonbBeVfKDFpNoM7BerBo2aVoDAkGh9zeeG9.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'web','mail daemon','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wwwmail','Imported from LDAP',NULL),(163,'focamfp@cfht.hawaii.edu','$2y$08$Zvk7emJdHtIdn4qocrbAd.35rh.Sv3aE/wvcXAA4kxdpZtf.X0ycq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Focam','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'focamfp','Imported from LDAP',NULL),(164,'jensen@cfht.hawaii.edu','$2y$08$D9iYA9RxCuZolt4KY2ZDbul7CqO/QpEzlf0439nCh2tmqpLb7.woS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Alyssa','Jensen','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jensen','Imported from LDAP',NULL),(165,'tcsiv@cfht.hawaii.edu','$2y$08$MKIdNT6bpq9QpnJVt3O49uunDRHBFXAkFrFh0nVGFQdO0GedB4gGa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TCSIV','summit Operator','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tcsiv','Imported from LDAP',NULL),(166,'puget@cfht.hawaii.edu','$2y$08$VRzP2c5Z0CKALviIh6bx2OF2fb6IrP.DF2OUSmCJz7JvqcSN08G7G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pascal','Puget','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'puget','Imported from LDAP',NULL),(167,'eder@cfht.hawaii.edu','$2y$08$gA7LrL0aJkdCH3ELJoZKtOJR0AOdF/o4xASi/ixXDUDv/t05Abfo.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Eder','Martioli','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'eder','Imported from LDAP',NULL),(168,'cf8@cfht.hawaii.edu','$2y$08$0bNOxDI3mxDHsWi4ygXmqOanOADm4fdJ9j9x7mzM1CNk6uPaq5KUi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Coude','f/8 CCD','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cf8','Imported from LDAP',NULL),(169,'hutchings@cfht.hawaii.edu','$2y$08$r2a2ooaHGvMzEr9Ki1AdjeGkV76qMELSWqU/e.N.cZHyAHjnhlrbe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','B. Hutchings','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hutchings','Imported from LDAP',NULL),(170,'wircamml@cfht.hawaii.edu','$2y$08$9bi4nGUOcmuhdBLLFCpe9edi94kaBziRQXcHg7VDK4zip7I97F.p2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Wircam','Mail','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wircamml','Imported from LDAP',NULL),(171,'mckenna@cfht.hawaii.edu','$2y$08$EhU0N2zaovDO30XJDRr8be6V7zBkEnmgRr.1Te9rbkK77yCI0q3ha','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Dan','McKenna','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mckenna','Imported from LDAP',NULL),(172,'salmon@cfht.hawaii.edu','$2y$08$PlUOqj3GjHp3Dd2Q8bEYJeQ5b.fqlo3iWzvOPAKhOkYwIw/LJdgzy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Derrick','Salmon','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'salmon','Imported from LDAP',NULL),(173,'rwood@cfht.hawaii.edu','$2y$08$ZGuhb9I0LRWiNb3pJPrGMuZmiA/cRsty19LBDrgGz3ySJA1JsK.sS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Roger','Wood','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rwood','Imported from LDAP',NULL),(174,'mosfp@cfht.hawaii.edu','$2y$08$6mGGQ10JDh8DeDlzHVyna.k6Q3UA3aB0X2GD71m8WMiNHeKnjKBqS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOS,','Fabry Perot','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mosfp','Imported from LDAP',NULL),(175,'karun@cfht.hawaii.edu','$2y$08$8sdoajhp1x0YgVgQAwqEU.pKXBP6TF.rWFXYb8.6gGOLNCWl9XAS.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Karun','Thanjavur','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'karun','Imported from LDAP',NULL),(176,'osis@cfht.hawaii.edu','$2y$08$MFGtvJATcLgCLYWJAkuuHufqt25tRUObX5ggKhNilJp8IbK7VCxrK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'OSIS','OSIS','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'osis','Imported from LDAP',NULL),(177,'seu@cfht.hawaii.edu','$2y$08$qyTl3OwzQoDM6ZzTnwaxNeEMR5U5W7U19gWdhRdOXDEl9nK5RNvKi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seu','Imported from LDAP',NULL),(178,'qcd@cfht.hawaii.edu','$2y$08$2I1Qv886PzJaDtm5bvGqqujMM/qkhUvtVRjRK6ZUJtsCeC21q2tAG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Quirc','Quirc','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'qcd','Imported from LDAP',NULL),(179,'neo@cfht.hawaii.edu','$2y$08$oot2MsblpEP9RdC61eOrTel.SCpJCaByC3nLDYy9PqdcEsL9beGGO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'New','Environment for Observing','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'neo','Imported from LDAP',NULL),(180,'webdude@cfht.hawaii.edu','$2y$08$QSXc0dEQKEWOajEgRaIAR.9DhWX8gUh55gB1jZt23jKYrnNOUmC72','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Web','Maintainer','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'webdude','Imported from LDAP',NULL),(181,'vivier@cfht.hawaii.edu','$2y$08$Bw2dtqEsuXeZ48DruYn9j.Mi/S508/g.6VUwEgYxkuu2KsnUoLr1S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'BOD','Gerard Vivier','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'vivier','Imported from LDAP',NULL),(182,'hesser@cfht.hawaii.edu','$2y$08$2hu5waaEkTjGQmB8rqaTJ.rdH/3g8YSdPNjTfia1GWcQliWYpqeOK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'James','Hesser','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hesser','Imported from LDAP',NULL),(183,'focam@cfht.hawaii.edu','$2y$08$TZrC8wmMp4g6WZUAcIMovupOOjD7/fgm4WfOclDTnggkyT8H7ugV6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Focam','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'focam','Imported from LDAP',NULL),(184,'ito@cfht.hawaii.edu','$2y$08$XPR7ATC41DfMwQxrypOKiePAXsB5BqAm7QHOnXonJggU8Z94hwHm.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Aaron','Ito','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ito','Imported from LDAP',NULL),(185,'camlewis@cfht.hawaii.edu','$2y$08$tqHRB9oOL6f6oUlT39rBC.09SMCBqS2aZw5Vk0bWF3WLwcoV.0ZTS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Cameron','Lewis','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'camlewis','Imported from LDAP',NULL),(186,'sitelle@cfht.hawaii.edu','$2y$08$D8G7DFJvvdVl5j28cFjTTO4lcLKlrqzfAwLYC1QTOewW.obCVKKwG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SITELLE','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sitelle','Imported from LDAP',NULL),(187,'daprog@cfht.hawaii.edu','$2y$08$12pWrO3me18iFGqB8Ac9MOnhbXT6YCvphV9Ts2WwoqNXE3e7guvHq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Magic','User','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'daprog','Imported from LDAP',NULL),(188,'wcdev@cfht.hawaii.edu','$2y$08$bJoIhRQjp27DRjzOkJSvseGNkjvljSlKwJnN/tgh/858SUIurI1lq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'WIRCam','development user','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wcdev','Imported from LDAP',NULL),(189,'veran@cfht.hawaii.edu','$2y$08$cQ6MTcY6AMFUiXjMCtors.8iflcuRYyVow6Il1Zl0edBK8ZQ636rq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean-Pierre','Veran','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'veran','Imported from LDAP',NULL),(190,'tsuha@cfht.hawaii.edu','$2y$08$gHUdpy5onPIaz6rX1YVTX.9CaCkfA0Z39Qsyl.hGi2pagi3ACepKe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Seizen','Tsuha','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tsuha','Imported from LDAP',NULL),(191,'ldale@cfht.hawaii.edu','$2y$08$rJxiRhM1cfxkZsaNyKcH3OoRRczHdRiXqhBcwtij4tNEhRUICKR5m','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Laurie','Dale','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ldale','Imported from LDAP',NULL),(192,'chock@cfht.hawaii.edu','$2y$08$ZWxJghL1FSEGQk9XGdEkA./tHKetP3tJS8nK.rxKg0cz7zuZvH2Zi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jon','Chock from Keck','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'chock','Imported from LDAP',NULL),(193,'lin@cfht.hawaii.edu','$2y$08$idt9hm6xgxGSsZteItzdyOB83cU7aKrbdGhAbyQnILAYDBqQhr0oG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ethan','Lin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lin','Imported from LDAP',NULL),(194,'jcc@cfht.hawaii.edu','$2y$08$sbgpbaeSo0KzJv4pcIUhTulZbLCxnbTbEly3Ig.CGZFaIuGoQul8S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean-Charles','Cuillandre','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jcc','Imported from LDAP',NULL),(195,'drw@cfht.hawaii.edu','$2y$08$pqu7lN6i3f2v8mleolpwrOG8XDf2POyGJGvosOcqGoWpg2T/dtkt2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'David','Woodworth','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'drw','Imported from LDAP',NULL),(196,'webclone@cfht.hawaii.edu','$2y$08$7vMApeHSL7TvbRKWV0aKQ.9fYdMsTHYlO2iNle.tV6xIIMwm3tlCq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'NEO','Web User','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'webclone','Imported from LDAP',NULL),(197,'robotics@cfht.hawaii.edu','$2y$08$mMi9IwFJ1o4E6R9hcMs8W.Us1uxqFCKRbqNf0sH9xWVSa3xmiQbH2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Robotics','Club User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'robotics','Imported from LDAP',NULL),(198,'espsetup@cfht.hawaii.edu','$2y$08$HkORc9enNCTJzB35zJBaVe0NlVrZOD9sR7bbvUn/Y5HU8IMUDmiTS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'ESPaDOnS','set up account','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'espsetup','Imported from LDAP',NULL),(199,'tmartin@cfht.hawaii.edu','$2y$08$wd5nEvtmxOQZjsynn2Aa8.XfySSqNlqyuFbLnvkTAHB0APdyfb1NO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Thomas','Martin','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tmartin','Imported from LDAP',NULL),(200,'obsmail@cfht.hawaii.edu','$2y$08$42p9JZ1cIiz8m5l6VgUJB.s/ZzRcH65clPr/B/yqM0IHeQNHZC3DK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Obslog','Mail','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'obsmail','Imported from LDAP',NULL),(201,'racoma@cfht.hawaii.edu','$2y$08$KJMCaYzdMXqwEx5AH9Ly1ecgXr6WTjcT9qHAE2kIOmYNwzZUMkXSC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'temp','account','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'racoma','Imported from LDAP',NULL),(202,'nobody@cfht.hawaii.edu','$2y$08$gCJOSVUqvlIN1qBes3WSBe4Y8Go0u8MU6A4mEaoLFVvU2ZlqBEqjC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mismatched','NFS ID\'s','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'nobody','Imported from LDAP',NULL),(203,'clenet@cfht.hawaii.edu','$2y$08$nMMFzTXTijc5sryvRLWpCecpwlmXX/B1vNeZ9CU4d76rYgjN3C90.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Yann','Clenet','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'clenet','Imported from LDAP',NULL),(204,'www@cfht.hawaii.edu','$2y$08$6fnzMXkGoR2XipyCp5oRaeGTewnmZjLK9jjdYalDBQOhF4HEqIjU2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Web','User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'www','Imported from LDAP',NULL),(205,'pegasus@cfht.hawaii.edu','$2y$08$43RmEWqXx0GAVTtOXZNweujxPmb7Cy.Tj9wW6YIKTTZ7ufPkZhVlC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pegasus','Demo User','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'pegasus','Imported from LDAP',NULL),(206,'thomas@cfht.hawaii.edu','$2y$08$ai08ifPEaVKGLq9dOIHy0uzS7O1XVil/v5LEmZoiQNDy.U/kmb7Im','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jim','Thomas','0000-00-00 00:00:00','2016-07-09 03:24:32',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'thomas','Imported from LDAP',NULL),(207,'redeye@cfht.hawaii.edu','$2y$08$Ss9OQYn2KuyY5UOcuc8QmOf2OHBVqyo5ZjSrTH2UOYR5lubTq/i2W','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'NICMOS','Infrared Camera','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'redeye','Imported from LDAP',NULL),(208,'ormail@cfht.hawaii.edu','$2y$08$hDjTjWU2lKuFkC9gi3sNFOshPvnB/xlaxYrdDvKyVNGm5BCSJjuD6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Outreach','Mail','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ormail','Imported from LDAP',NULL),(209,'fouque@cfht.hawaii.edu','$2y$08$CcBkON2G3xFwaJWDdwbG3e19vxyexEVL7jeQSTiwJtjuHvlfWAi3q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pascal','Fouque','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fouque','Imported from LDAP',NULL),(210,'tiger@cfht.hawaii.edu','$2y$08$LMM5HSBhD7aTyXsdvYAvleKAFtYDseZe1V7THd06t9/QsunbPYP1G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tiger','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tiger','Imported from LDAP',NULL),(211,'david@cfht.hawaii.edu','$2y$08$fpTTjJkqEa5Ow7WNZx9xCe29MUack9UEU6S78mXiLdjtXy3CE.eB6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','David Bohlender','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'david','Imported from LDAP',NULL),(212,'alles@cfht.hawaii.edu','$2y$08$BCg07v0uwPYbGqj1T82or.F5QK.ZqjS.YX0FUTinBmpQTb2CRe.LS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Rosemary','Alles','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'alles','Imported from LDAP',NULL),(213,'wood@cfht.hawaii.edu','$2y$08$1Qb0Jmpncw07F613kIdutexIwtOjMive0mf/fSznwiSag0xvIPgeS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Susan','Wood','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wood','Imported from LDAP',NULL),(214,'nrpe@cfht.hawaii.edu','$2y$08$aE2BNrJbHT6L9ck0IIetJeaQNsP52tvh6D/w3LOwWNHTZLt9NNFk6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Nagios','Nagios','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'nrpe','Imported from LDAP',NULL),(215,'grif@cfht.hawaii.edu','$2y$08$Lm6Qb2E0WyngqfFCtBHFpe8usS.pNu2sD6fFIfj4swkEk61FH2a7O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'AOB','+ KIR + GriF','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'grif','Imported from LDAP',NULL),(216,'ice@cfht.hawaii.edu','$2y$08$dd5hxiYTkItaoGbL29dHquk4yjWrzyuZ.QKc07rqA0rNa66dnMiUS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Slip','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ice','Imported from LDAP',NULL),(217,'mosfpeev@cfht.hawaii.edu','$2y$08$GvwA4AKMbvdjrMvcUjyRCOtEzqSopgTlBP.h6zBixS/WzqER4HKHK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOSFP','with eev','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mosfpeev','Imported from LDAP',NULL),(218,'morrison@cfht.hawaii.edu','$2y$08$4iZpddJXEnIL2a13jRytVejaFewvxF0tOlllFOICnenZR9Cs/2ysO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Glenn','Morrison','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'morrison','Imported from LDAP',NULL),(219,'majordom@cfht.hawaii.edu','$2y$08$RpBMqDPW62fWQj9LpwsZEuRVs2vCGdW8Fsby.Pi8HCs8WDFiXvwgO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Majordomo','Majordomo','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'majordom','Imported from LDAP',NULL),(220,'mclaren@cfht.hawaii.edu','$2y$08$xKnuNal2TEsfdPckTHtqzOSIMN.YuDNHTiWxzDzxJtRUkQUgDZhfG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Robert','Mclaren','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mclaren','Imported from LDAP',NULL),(221,'bocquet@cfht.hawaii.edu','$2y$08$xYkN15AoEZZjcIzk3QKpJebylV04.CLxy9TfnNOYn.0je8jEgTRN.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Aurelien','Bocquet','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bocquet','Imported from LDAP',NULL),(222,'logger@cfht.hawaii.edu','$2y$08$xvfAWSD45UqLQiOeRWEKe.R4..GIrFcw8flRSyfGInUG9BHZWq0n2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Data','Logger Project','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'logger','Imported from LDAP',NULL),(223,'plant@cfht.hawaii.edu','$2y$08$vRB3y7m3khWc0S5Gwk4Bae/Vd/4OPiHtl8O89ao.IWvl9preoYjNm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Observatory','Plant','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'plant','Imported from LDAP',NULL),(224,'oasis@cfht.hawaii.edu','$2y$08$tQUzO9jF8QiL2xvwsYfwFeYgGhT4LCQJDt2FYjqEnf1N4q3IkxwKK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'OASIS','OASIS','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'oasis','Imported from LDAP',NULL),(225,'croll@cfht.hawaii.edu','$2y$08$aWOENFJtKIHjbC18HE3xTukFC2PAAEgNiagVYgTW6ZQPrznqhsEdi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bryce','Croll','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'croll','Imported from LDAP',NULL),(226,'billy@cfht.hawaii.edu','$2y$08$ZqAzyR38SdNrWHvA1QZlTeIYYzh1F28mWKc5NbqzoYOx3xP0SHxbe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Billy','Mahoney','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'billy','Imported from LDAP',NULL),(227,'pritchet@cfht.hawaii.edu','$2y$08$ROohA9HPP8lTFQd0BEvNIOMm4KfVU5jrK6GJJPH6cXCRSefw4Am8O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Chris Pritchet','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'pritchet','Imported from LDAP',NULL),(228,'flyeyes@cfht.hawaii.edu','$2y$08$mWMyJdcWvegAYvFwaV779elNLwCzSlCFI6CBdOUI06GH/EqKLq90.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'FlyEyes','FlyEyes','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'flyeyes','Imported from LDAP',NULL),(229,'chihiro@cfht.hawaii.edu','$2y$08$AfUDeJLQT9eglCPX8Dkh3uLV46Lm1HH08EyLQ79XCgjx4z/qErkHi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Chihiro','Sasaki','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'chihiro','Imported from LDAP',NULL),(230,'cadcops@cfht.hawaii.edu','$2y$08$5aNwUcA3N96hiiSf7UmPbu3JH0DbLjE9E/39AzufeHH8bxDqcbPC2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CADC','remote access account','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cadcops','Imported from LDAP',NULL),(231,'sloane@cfht.hawaii.edu','$2y$08$zDliN0BCwb9oY81AX76WpOlMu2EMd8oLej9fIwV.BuBPdBgfvu7oi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'James','Sloane','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sloane','Imported from LDAP',NULL),(232,'isabel@cfht.hawaii.edu','$2y$08$HyuHtWRXTDDM2yMxvQUgOO/rtHck1./Ybl.kSBOyDA/qHB1QD1Spe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ilima','Isabel','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'isabel','Imported from LDAP',NULL),(233,'harris@cfht.hawaii.edu','$2y$08$MY9ksaHXGvh7JQD4cjkti.phD11F7/eRoYaJlbPd8lrUKieSb8WDa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'William','Harris','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'harris','Imported from LDAP',NULL),(234,'starr@cfht.hawaii.edu','$2y$08$atbdwNqjdPqMo5wOZKTWY.bOkluq8eU7TjIQ7afJ46FMgzpACReZO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Barry','Starr','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'starr','Imported from LDAP',NULL),(235,'imaka@cfht.hawaii.edu','$2y$08$ofcuBvYqOW73kKaZBCJFA.kcL2W9N.uZw5DX0u0CE7YJq8ZQTkfU.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Imaka','account','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'imaka','Imported from LDAP',NULL),(236,'filao@cfht.hawaii.edu','$2y$08$b12rsDGnwDPYC5Fsw2jKDe6sbxAncJ1kL/xaFy8PuhO7/O3RHDSKC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHT','IR with OSIS and AOB','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'filao','Imported from LDAP',NULL),(237,'oasiseev@cfht.hawaii.edu','$2y$08$ytTd1w2elEw3cabrcARC6eRxdreopeX7zTTCZ3rSZrOR5A6NlWct2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'OASIS','with eev','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'oasiseev','Imported from LDAP',NULL),(238,'cfhqsir@cfht.hawaii.edu','$2y$08$aCt0OinKnQSYLa7k0bkioeV1GQ2EXMQFEEV6GjyV5V0lslfsO1Q6O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHQSIR','account','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cfhqsir','Imported from LDAP',NULL),(239,'canleg3@cfht.hawaii.edu','$2y$08$RNMvO2lVSxR9tuA3FTP0uOFrJxcKzZQ/pEl1TO2Z/T3wNde0G7lRC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Canadian','Legacy Survey Group','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'canleg3','Imported from LDAP',NULL),(240,'mrwolf@cfht.hawaii.edu','$2y$08$IFUxHvz5gCZYiSPnlgtKX.FUh41HiOskNsi8XD1mpM.R4P.TJfUf.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Detector','Troubleshooting','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mrwolf','Imported from LDAP',NULL),(241,'circus@cfht.hawaii.edu','$2y$08$wsN5FIWSC3A7PaUGnXhQVOJ4WcLAUr/ARn2b4hKeCuLOnk4jQ.EOK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Circus','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'circus','Imported from LDAP',NULL),(242,'slist@cfht.hawaii.edu','$2y$08$7uf1hREBG5bt3cdrHO1aSeK.8ESOfgJSHcINVadruK8wCbtp1tKEm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Smart','List','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'slist','Imported from LDAP',NULL),(243,'gecko@cfht.hawaii.edu','$2y$08$mnmkftAy3rEEE6yJs3Wf2OQl49b6Tw4iA/M7QyVEj6qVrppAUcMPC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'El','Gecko','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gecko','Imported from LDAP',NULL),(244,'metz@cfht.hawaii.edu','$2y$08$LiK5nRuol25jNeCtZfTWLOaEAcI/fzcQUQ8lhlGYO7aARjDOHM.66','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Brandon','Metz','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'metz','Imported from LDAP',NULL),(245,'basa@cfht.hawaii.edu','$2y$08$02VOnwQhCWGC5m4zDIe8E.c3a1M9w4XOPHhbeyMfIoSX28RTpgcB6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Stephane','Basa - Visiting for legacy survey data Aug 2012','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'basa','Imported from LDAP',NULL),(246,'swcleanup@cfht.hawaii.edu','$2y$08$lANWC1Zppt3ZAMUsobdOYeixyumxXpe2L2Nsuy3GRYbKGunoOkRhO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Software','Clean Up Account','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'swcleanup','Imported from LDAP',NULL),(247,'kalirai@cfht.hawaii.edu','$2y$08$9Q7O4oyD0MPE61ADiD9VKuTX9ZBEQNLgaqAMcSPNXEOH5nbCgXH1a','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Fahlmans','temp assistant','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kalirai','Imported from LDAP',NULL),(248,'vmalan@cfht.hawaii.edu','$2y$08$Bm0nXqqCeEcxTOD9IFMAI.FykP.S5zA0xZ5QL2FIxtlMIX25q7vZO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Van','Malan','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'vmalan','Imported from LDAP',NULL),(249,'le-gal@cfht.hawaii.edu','$2y$08$zcykp5knxz7akrgGVsv0d.cJX48yJFGlQRoOmOpHIDflPggdFXkEm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Maelle','Le Gal','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'le-gal','Imported from LDAP',NULL),(250,'megatest@cfht.hawaii.edu','$2y$08$LFBhEZM02hfyqdw6aXeXi.gRLVmL5dG8p6zJBpFT3UQ8f0DZTHhvm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MegaCam','test','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'megatest','Imported from LDAP',NULL),(251,'cldsensr@cfht.hawaii.edu','$2y$08$hBvneuslSEVcxldsOqYhCuz/rKXsCqu0GP.UTlKdJOui8QwcKwhFi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Cloud','Sensor','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cldsensr','Imported from LDAP',NULL),(252,'roberts@cfht.hawaii.edu','$2y$08$6ikQy5NxO2zGmA6rRMLFCOZkHM7mjbyWmV03tvn1l33U5q8mvLrmi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Larry','Roberts','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'roberts','Imported from LDAP',NULL),(253,'richard@cfht.hawaii.edu','$2y$08$rNonH5FQHJ3ahppPHtRnSOYBbewCs/KsjSn1pn7cuEF8leLJIIOyS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'BOD','Richard Normandin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'richard','Imported from LDAP',NULL),(254,'hainaut@cfht.hawaii.edu','$2y$08$2hD4UKoB6zha35o4E9DcO.vJY/4SITGo/WCUoywf9/.V1DSf2.eOG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Marie-Claire','Hainaut','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hainaut','Imported from LDAP',NULL),(255,'tcsivb@cfht.hawaii.edu','$2y$08$fZ8dcRJmKQdgf9WbmRzaV.VQJTLOn83orEV.SMZaBDhjvO2JjNtxW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TCSIV','summit Operator (backup)','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tcsivb','Imported from LDAP',NULL),(256,'palila@cfht.hawaii.edu','$2y$08$ph8tL7KVHOHePA8BJ2jsiORa9joIZHX5dlfucTeGzxmOXTFJK4TUC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Palila','Focal Reducer','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'palila','Imported from LDAP',NULL),(257,'hadoop@cfht.hawaii.edu','$2y$08$h6JeIasIjxoPwtnHYfCPXu3KttreQjVBYlsLs8IiP0j4kILbrkCrC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Hadoop','User','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hadoop','Imported from LDAP',NULL),(258,'tburd@cfht.hawaii.edu','$2y$08$erze3DuzCi1q5c3HnSWxpeowMRI997KP4G9Fvv9lfWBoHv1fKUTV2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Todd','Burdullis','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tburd','Imported from LDAP',NULL),(259,'news@cfht.hawaii.edu','$2y$08$1Sso6tTa84vkO77ct8xNeODbSGf6.QnmtOjL1UldwMRgVcbtcgBwS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'USENET','News','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'news','Imported from LDAP',NULL),(260,'etc@cfht.hawaii.edu','$2y$08$1uu5eZrdC3ofV8bb0CbwhOYIySH7MutB0MNGg5grb3sLl1KnFqZpy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'ETC','User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'etc','Imported from LDAP',NULL),(261,'forveill@cfht.hawaii.edu','$2y$08$B6oACMmNNChH5vfqIoDgzu.sp8c5fvjKyGXYjgmegz5i4FC3NqB2C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Thierry','Forveille','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'forveill','Imported from LDAP',NULL),(262,'visitor@cfht.hawaii.edu','$2y$08$bNRYIFMSn92UlMhsYbi43usguDiupLwZVSSDjaGp7gVBtdzCGV9wq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mail','Visitor','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'visitor','Imported from LDAP',NULL),(263,'system@cfht.hawaii.edu','$2y$08$gVueTZ0lfCv9lRlbowjhF.PbSlIDU9.wOM40fuYryOV8LPY.O0VPG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'For','UREP rdr','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'system','Imported from LDAP',NULL),(264,'sumweb@cfht.hawaii.edu','$2y$08$Oa9fIKA8jFMiPWNDzsqiR.LP4GqFxWDflYwxBMjVfxQkREJ9VN.F6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'NEO','summit web server','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sumweb','Imported from LDAP',NULL),(265,'elixir@cfht.hawaii.edu','$2y$08$cyi7DbZ4KY3sqV6kos3GM.09qbFPs6D0yP2sIhXjofZWhsK1dxWKW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Elixir','user','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'elixir','Imported from LDAP',NULL),(266,'rydra@cfht.hawaii.edu','$2y$08$zPe2ZkjnJQ65yHGk8vvUH.mNROmklHz4/i6JEQ1bV0zqetIwjBkzK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Rydra','Kloepper','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rydra','Imported from LDAP',NULL),(267,'luthe@cfht.hawaii.edu','$2y$08$IOQe6us8eGJEqEITHGB59ucBHolv38/wbBpM1tADvqj8so96edI9W','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','Luthe','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'luthe','Imported from LDAP',NULL),(268,'seun@cfht.hawaii.edu','$2y$08$VkL5yZPU5fzEel8l7YKd2eJOMLxF/pLft1hxszLSl.IHaYtBnGy6O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User on noeau','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seun','Imported from LDAP',NULL),(269,'cdas@cfht.hawaii.edu','$2y$08$0kNE44KUumoLC0zsuAdUDeN7tB6p0ilB1PAkR6hqliMhP6hsI1w7G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Centre','de Donnies astronomiques de Strasboug','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cdas','Imported from LDAP',NULL),(270,'mugridge@cfht.hawaii.edu','$2y$08$H0gbhinZ16otJxcJdRGPT.SVooHIP7dWTNfkJWig9VHXPeErgUqdm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Paul','Mugridge','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mugridge','Imported from LDAP',NULL),(271,'beuzit@cfht.hawaii.edu','$2y$08$qR9aj8BqUSIpx2aRLVLXgeNeZQrBrl0Ew/z1u6ykzf/Xt6DSL/zaa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean-Luc','Beuzit','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'beuzit','Imported from LDAP',NULL),(272,'trini@cfht.hawaii.edu','$2y$08$UJKDkgGY6rIgda2mOH2yQO04JgxWdECO0HYcjyLZyUmbN7eidQtAi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Trini','Grundseth','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'trini','Imported from LDAP',NULL),(273,'midas@cfht.hawaii.edu','$2y$08$VHuRHbnpsqdbq6UcYygGWOftfuEq/n.eCAlbvGMMfTqPpJ/IsSJm.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MIDAS','Guru','0000-00-00 00:00:00','2016-07-09 03:24:40',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'midas','Imported from LDAP',NULL),(274,'uh8k@cfht.hawaii.edu','$2y$08$LPApoeXRZxpgcHz5ipA97uaI/1X1bVvu9VP15Ml48D44ks8.FrJn2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'UH8K','Mosaic','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'uh8k','Imported from LDAP',NULL),(275,'fort@cfht.hawaii.edu','$2y$08$XjqFCQFms1n6ph7d9I8wee/LeV0oLSCwDq5B0v3wVVdvO6OtFH0ke','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'sl2s','account','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fort','Imported from LDAP',NULL),(276,'dvg@cfht.hawaii.edu','$2y$08$SeAxTMRjBFprRYY8by1NQONgJPIw4OmStKObiWrhVDpypvDyQ9J0y','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'David','Valls-Gabaud','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dvg','Imported from LDAP',NULL),(277,'sarchnai@cfht.hawaii.edu','$2y$08$Y39hhhGifmR0zgXTWABBvu5P9IZCv2QGD3mXAA33dPQoGKxf77SvS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','archive user on nai','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sarchnai','Imported from LDAP',NULL),(278,'lindsey@cfht.hawaii.edu','$2y$08$zkCHX8Kl2IIxTZUHiblbuOfQycxhiWRneubSfUd/yOBo36lF0246a','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Elissa','Lindsey','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lindsey','Imported from LDAP',NULL),(279,'jwright@cfht.hawaii.edu','$2y$08$10ohA8avRJftQb97N53xM.NU.s4z.bRhnNGQvCplrj7S6VbApZWaa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jim','Wright','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jwright','Imported from LDAP',NULL),(280,'holborn@cfht.hawaii.edu','$2y$08$ABEUzaUHijS07pWcSkSRZOker4A3egztCxv4j8qw1aD559L5K2jBC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Anne','Holborn','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'holborn','Imported from LDAP',NULL),(281,'hoffman@cfht.hawaii.edu','$2y$08$OvK5b8QmxJX7N4i3cl13M.ev4oBhHSM0VxJD1kkiSCXH7zqujYiIC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'James','Hoffman','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hoffman','Imported from LDAP',NULL),(282,'delorme@cfht.hawaii.edu','$2y$08$RlIXpSAJVF7AZKjVDYmtWe85LFJgU7hck/I2rwrYIwOIbwqj.Q6t2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Philippe','Delorme, intern','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'delorme','Imported from LDAP',NULL),(283,'taroma@cfht.hawaii.edu','$2y$08$ARMOqQIF68HDcC2zI5JP6O6WxNcteWK4oDydgb1oA6CBrbn8fUoUu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ralph','Taroma','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'taroma','Imported from LDAP',NULL),(284,'menard@cfht.hawaii.edu','$2y$08$hZiC8t2pSDIHQauFwoarH.wLZACw7VnyryAHZbMFml2tzn0MCVUEW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Francois','Menard','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'menard','Imported from LDAP',NULL),(285,'casoli@cfht.hawaii.edu','$2y$08$FtaXHrjfKoZiBKU04lkfFuo00AcZxlteJ4LVkRhEIUAb0n.PSxjWO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'BOD','Fabienne Casoli','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'casoli','Imported from LDAP',NULL),(286,'cafel3@cfht.hawaii.edu','$2y$08$qoMdggfB2dPVzHMv8oW7DeFp8EvuNZrI8y4e.HSqVTtePh1e3LVSS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CAFE','with Loral3','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cafel3','Imported from LDAP',NULL),(287,'seuni@cfht.hawaii.edu','$2y$08$phk1MGzdgTxyLAweRufBoOBZtkjGqYmxMF.KhgHMdYjL47WLXKodm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User on niele','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seuni','Imported from LDAP',NULL),(288,'song@cfht.hawaii.edu','$2y$08$PfLO2nFOInfaRi3POxZKfuoQwYtAtMnFN0KTOqhjoXq76O3VtPciK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bobby','Song','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'song','Imported from LDAP',NULL),(289,'elizares@cfht.hawaii.edu','$2y$08$QRHMZyuia3678mqWom60Gu5EfJOBWi/6aJfmKu3Ujjz.iaiyDHKRu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Casey','Elizares','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'elizares','Imported from LDAP',NULL),(290,'couture@cfht.hawaii.edu','$2y$08$3ln68qQBlhWc3OJIat1Xc.dfWwQ1ZotXJb7uAjulrP6P5ttJQF1Wq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pierre','Couture','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'couture','Imported from LDAP',NULL),(291,'potter@cfht.hawaii.edu','$2y$08$AWxfwjFNeZYslzU9A2Up5.q5dmMEwxtueB1mqHJ7RMn577AFfnqra','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sharon','Potter','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'potter','Imported from LDAP',NULL),(292,'bonini@cfht.hawaii.edu','$2y$08$ZFybymAvqgIR5rM1xkneROYWlZOJVMgDptCXopduWDQHwHUP5Jk/C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Clement','Bonini','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bonini','Imported from LDAP',NULL),(293,'jamie@cfht.hawaii.edu','$2y$08$m5rAw9jCj4HNnFGCSTI4xuUKnNzBepZE88X8EbWhf2vnxCB25BRJ2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jamie','Kilkenny','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jamie','Imported from LDAP',NULL),(294,'link@cfht.hawaii.edu','$2y$08$E4aM4Z3CYUCDV1Hjhdxypu6Fd4vkterVhQbINUHcdoX3hei6pBbC6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bob','Link','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'link','Imported from LDAP',NULL),(295,'cfhtprop@cfht.hawaii.edu','$2y$08$IpLsfhL9xQ2eR1tuoOBjZ.8mRSZiyzIXOzVepbPvqnCKjYedNutlW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHT','Proposals','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cfhtprop','Imported from LDAP',NULL),(296,'celtsite@cfht.hawaii.edu','$2y$08$1iOdxwBw2HFe4gv9QIasKOH5VnVLIwncGHmycB023LzxWCzhJarPC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Celtsite','DIMM user','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'celtsite','Imported from LDAP',NULL),(297,'transat@cfht.hawaii.edu','$2y$08$1i99at8OK9pLyO7mrNwJzOQXTsm.lXqlVvC9FAKcaB/OoxL0WOFPq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Transat','Project at RENATER','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'transat','Imported from LDAP',NULL),(298,'redeyew@cfht.hawaii.edu','$2y$08$LMq223Nqtrz585NdJYhE7OK.zetNG3RdsET1DAdhucsFIkEGZrPCG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Wide','Infrared Camera','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'redeyew','Imported from LDAP',NULL),(299,'yuxian@cfht.hawaii.edu','$2y$08$vMQxBUOChAAw77yz2FE1IenjtaB4Fs15FGz8ft5jj4eg85dDEkZwS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Yu','Xian He','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'yuxian','Imported from LDAP',NULL),(300,'carmen@cfht.hawaii.edu','$2y$08$QSNCOsETcb398gXXxQ7wyu6d/MTev1F5Kw8odAphWVfEBEyUaLHKi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Carmen','Valls-Gabaud','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'carmen','Imported from LDAP',NULL),(301,'snert@cfht.hawaii.edu','$2y$08$zanoG0dms2yX4qhOVVIRg.UW462CjQv/CvpKdS.jqxhp/WKR3ZliG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SNE','second account','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'snert','Imported from LDAP',NULL),(302,'smmsp@cfht.hawaii.edu','$2y$08$xAYRqwjMBquLPzyXmWcSS.hxgGWTeDkn50zLvlqbRexU6C/e.3JhO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'sendmail','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'smmsp','Imported from LDAP',NULL),(303,'mocam@cfht.hawaii.edu','$2y$08$ELmbJrEwc0FLpHA0trCkPuUld6pZ2hoQUsSKv.540ToXbPRPXh7sy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mosaic','Camera','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mocam','Imported from LDAP',NULL),(304,'herb@cfht.hawaii.edu','$2y$08$1RTv8Hoa2gWPuZBpP3zXFe8/PCE7gT31b4ITaruYoW/n0fu9CUfee','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Herb','Woodruff','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'herb','Imported from LDAP',NULL),(305,'sis@cfht.hawaii.edu','$2y$08$Ts2CAUR3Pwjs9czSKeZLMuasgQE2H2BYDYuT9Jz1Dn7BqJV7vtb8W','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Stablized','Imaging Spectrograph','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sis','Imported from LDAP',NULL),(306,'christopher@cfht.hawaii.edu','$2y$08$NJ2sKvL26DWIhsrucHgWBeGsOxKijXrmLB8A31O1fXQ7hRsJAwkwO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sheri','Christopher','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'christopher','Imported from LDAP',NULL),(307,'ptolemy32@cfht.hawaii.edu','$2y$08$Vyb8tP7POQaCLzQN2uWiE.li9S82QRt9wPCUMYliY66Iy2UlDL4YK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Elixir-vm32','User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ptolemy32','Imported from LDAP',NULL),(308,'hayworth@cfht.hawaii.edu','$2y$08$KrMR4rltoIAGCZ4JRhYmfOWZQMFOpmLTTDdNf7WCVd5rfZtQA5k.u','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jayson','Hayworth','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hayworth','Imported from LDAP',NULL),(309,'sybcron@cfht.hawaii.edu','$2y$08$oEDZh7zgrmur5FYahAKkKOGqR3JtyJ6.Y/RWKxM0nI3ZDxjQJM8eS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Account','for sybase cron jobs','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sybcron','Imported from LDAP',NULL),(310,'qsomail@cfht.hawaii.edu','$2y$08$PH7dxmmPkNsZrFdUE7qZaOeRXhaFOvUB5Ak2j6mZvlN1.klarjWGm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'QSO','Mail','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'qsomail','Imported from LDAP',NULL),(311,'fischer@cfht.hawaii.edu','$2y$08$Ld7HzgCfBoFTN6ClfnJfj.tJUMMmDUBJcIRQL60/pXTt.AiwRSwf6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Linda','Fischer','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fischer','Imported from LDAP',NULL),(312,'demomos@cfht.hawaii.edu','$2y$08$H8RsZwth8CHTzAKA7OS3euI2.K7dVZ0Pikuzp2l3TELaQ91p2fAcK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOSDEMO','MOSDEMO','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'demomos','Imported from LDAP',NULL),(313,'sywang@cfht.hawaii.edu','$2y$08$XHS83Mbp7KY2HwBP8rkbWubgF0z0XeBVmBUBKv8q.O6ddscApfT5O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Shiang-yu Wang','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sywang','Imported from LDAP',NULL),(314,'moutou@cfht.hawaii.edu','$2y$08$DQpAm9NI3iqs5g5OvyJlLeveMjoKjViqRCqb6z7TnPFUp/L3miJfO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Claire','Moutou','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'moutou','Imported from LDAP',NULL),(315,'picat@cfht.hawaii.edu','$2y$08$IJUk39ZHDSAxZ0BzDxPB5.bV1kUt6Mi9N7fq8XkZZl43BYeh.BObi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean-Pierre','Picat','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'picat','Imported from LDAP',NULL),(316,'ohana@cfht.hawaii.edu','$2y$08$WMQA0P6pOH4rzgo4ZzZlTemvMUK82t.PFYvi9eJ.WaBiuDdGLpqai','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ohana','User','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ohana','Imported from LDAP',NULL),(317,'dos@cfht.hawaii.edu','$2y$08$GCGbw8d4iKfVWAihgQD62etybum2z97CKliTUNtv6ZGkbJFSxV/zm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'DOS','Guru','0000-00-00 00:00:00','2016-07-09 03:24:51',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dos','Imported from LDAP',NULL),(318,'kaimalino@cfht.hawaii.edu','$2y$08$FkFeQsMO7fnT99wQkWhKguk6kPCOpMg2L3yVsipX1N8oghWvxnfGq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Kaimalino','Kaimalino','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kaimalino','Imported from LDAP',NULL),(319,'boutenko@cfht.hawaii.edu','$2y$08$XVfNLuIzetKP6VO03ZD3ZOO4YTlicnmxBrUBqDuMMVrLL1cFzfr6.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Vladik','Boutenko','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'boutenko','Imported from LDAP',NULL),(320,'archive@cfht.hawaii.edu','$2y$08$Rt6nLOBXuce5pxJXMLKS3uq4SDog2wh228Tlj47Atf.c1PoN8okcW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Archive','User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'archive','Imported from LDAP',NULL),(321,'teeple@cfht.hawaii.edu','$2y$08$M34RBCoTxL6uoSjEhiVJFe.QITuEn0jM2a2nvs3plzyBcWHUh0aRW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Doug','Teeple','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'teeple','Imported from LDAP',NULL),(322,'mercer@cfht.hawaii.edu','$2y$08$yUmWn9ocs6LAa0fx8lCC8OZr8k84CSCXomlNN7IYggp6ONJFmUg9m','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tanis','Mercer','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mercer','Imported from LDAP',NULL),(323,'devost@cfht.hawaii.edu','$2y$08$O3SrDNmkzMta3dRgBceNtOTHUTSepqYGSMR.cKtGJcB7xn5QRU1I2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Daniel','Devost','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'devost','Imported from LDAP',NULL),(324,'dantel@cfht.hawaii.edu','$2y$08$mosPNpgO7D5wFH3ChJmpEeWpAPFiPz0zDAA7gfbArlWY4DbH6K0Iu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'sl2s','account','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dantel','Imported from LDAP',NULL),(325,'albert@cfht.hawaii.edu','$2y$08$YmnGEcNhzJ1ZaEOdNW7uvuXCk1aVI.0k3TFdshRf7t7PB0m5.FIn2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Loic','Albert','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'albert','Imported from LDAP',NULL),(326,'opera@cfht.hawaii.edu','$2y$08$neteYkY0QK6xstPMKzlanOy2fJSmD3pE9bhFdi.xApJV3kjNhAtlK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Opera','user','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'opera','Imported from LDAP',NULL),(327,'seul@cfht.hawaii.edu','$2y$08$uzigBW46PcNF8ZlRZbxvruljduXVwHgrNXwZM4Fv65FzSpFSJ7/Ia','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User on lokahi','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seul','Imported from LDAP',NULL),(328,'iiwi@cfht.hawaii.edu','$2y$08$VSUzUy3RMEvPFSQCnsF2EeL6R5EKDdcs/INzJc76zcjRaUGNeVN72','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'iiwi','user','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'iiwi','Imported from LDAP',NULL),(329,'jbh@cfht.hawaii.edu','$2y$08$E9HOlVoi3fFHcTxQf4ziZub1Q5edSG2Wbio/m2j5fYP5FGPW.m1fS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'John','B. Hutchings','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jbh','Imported from LDAP',NULL),(330,'han@cfht.hawaii.edu','$2y$08$We0jb3q51kvvnEFC3XLCo.FjdFBiAl6ZtrfGHVaPXgFD8/FMTsUeW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Inwoo','Han','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'han','Imported from LDAP',NULL),(331,'patrizia@cfht.hawaii.edu','$2y$08$jM6SUL4nIotbQB8hI86PYuAF81YL8NKIra86qKPtxGhxmFURpjw3S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Patrizia','Kilgore','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'patrizia','Imported from LDAP',NULL),(332,'catalano@cfht.hawaii.edu','$2y$08$OIddGIBQA45qvaLaC7LOpOD5GJ0o.qGRxrfLhZoXMJ0sfOJZdjI/i','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Camille','Catalano','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'catalano','Imported from LDAP',NULL),(333,'mychun@cfht.hawaii.edu','$2y$08$mQNBRKm3yXffwYTq6gNoRefMn5rF.m/0JUl5nDBzn3JyGi.sY0wpG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mychun','Mychun','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mychun','Imported from LDAP',NULL),(334,'banana@cfht.hawaii.edu','$2y$08$VSPRmxFyBfXoTGKrbflc0OXcj//2El4b8J8P8mRvs/r0OUybmTJ46','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Slip','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'banana','Imported from LDAP',NULL),(335,'jmori@cfht.hawaii.edu','$2y$08$jztp1BfHka8aywaO7mAH2ORAe/0JFkJY04VuS5ZP.ihquwR3mT9sq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jeff','Mori','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jmori','Imported from LDAP',NULL),(336,'ccdwt@cfht.hawaii.edu','$2y$08$iIhRFy0fhxepgDNWAa7lGeCHpwgJtXEvquMYWRwAwXDtqwll3d7T.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Waimea','CCD on titan','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ccdwt','Imported from LDAP',NULL),(337,'asiva@cfht.hawaii.edu','$2y$08$dxf6VEe1zMQVtTpNjoSJx.5eHQoG7n1csaxiAhR4LteVDVRLbt64O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Asiva','account','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'asiva','Imported from LDAP',NULL),(338,'dean@cfht.hawaii.edu','$2y$08$J84vamjqM4wfBbT3OkVyoer1.PrYFLbAunHGC0IefK9vkttVvuNCy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Dean','Josephson','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dean','Imported from LDAP',NULL),(339,'cuby@cfht.hawaii.edu','$2y$08$j39QPGehNPa1S2yrlBFhd.FPRhbMdBIztv8kFGsPFGGCDZIQZlcXK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'BOD','Jean-Gabriel Cuby','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cuby','Imported from LDAP',NULL),(340,'mos@cfht.hawaii.edu','$2y$08$NQnKuhi0JJS2D8SFo5hJzu5P1EhKw/503SEe7ehcpBF19l..bi16C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Multi','Object Spectrograph','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mos','Imported from LDAP',NULL),(341,'demomosfp@cfht.hawaii.edu','$2y$08$fo1cbRp3NwkT0ccn7aKM3eXBzluYqewfgIRTz9Eg7eAIZGyDS/yAm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOSFP-DEMO','MOSFP-DEMO','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'demomosfp','Imported from LDAP',NULL),(342,'minster@cfht.hawaii.edu','$2y$08$JFVF2D1UMI0EVtwStmMqx.OvpPQkPe3nO5ayurNKeGf92EMLHfr5C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean-Francois','Minster','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'minster','Imported from LDAP',NULL),(343,'cabanac@cfht.hawaii.edu','$2y$08$fNsHVqbn8ktM8CqZei3i7uQLhLjBP8ND4U3A3l5Sx7iX61AmI0yCK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Remi','Cabanac','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cabanac','Imported from LDAP',NULL),(344,'graces@cfht.hawaii.edu','$2y$08$AequmhMPYmKE55MJHYzsBePhJbHF9J4GvO2ReL8VlgDbwd6m05U0y','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'GRACES','user','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'graces','Imported from LDAP',NULL),(345,'george@cfht.hawaii.edu','$2y$08$TQUOwia5bihf8gRCb3QAD.R784Gfm/x.mMBl06G4Nbvc3dJSRYVd2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tami','Jo George','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'george','Imported from LDAP',NULL),(346,'davidh@cfht.hawaii.edu','$2y$08$THmTB1lODjfyhdPa5YqEDOI.Uq0xJ4bq6VhJt3y/vDijvubf3QvG2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'David','Harrington','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'davidh','Imported from LDAP',NULL),(347,'nate@cfht.hawaii.edu','$2y$08$xe9FgBwR0iBzgxQ5sWc8XeBCaGNLkAVGaRsmWEpJXpZZfmzmngtEK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Visiting','Student','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'nate','Imported from LDAP',NULL),(348,'cadc@cfht.hawaii.edu','$2y$08$3uFL0LXoguEO9F8VySAgUevuwxgfnn5QWwYCD1D2yXSXI8R73jNaG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CADC','User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cadc','Imported from LDAP',NULL),(349,'tos@cfht.hawaii.edu','$2y$08$4eCkzvA10KU5we2lAn0aSO0Blrt.4YSmudseNcBhHXu3ATH9b8.5q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Telescope','Operators','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tos','Imported from LDAP',NULL),(350,'spv@cfht.hawaii.edu','$2y$08$71Div0Tg762bQEJHPcsbWuWNKZtY9YobDvuvrxG3Anm834WASgmV2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Skyprobe','Skyprobe','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'spv','Imported from LDAP',NULL),(351,'skyprobe@cfht.hawaii.edu','$2y$08$BNtGCHjjj2bm2ZSHyN5ygeWEGOlztRkVN/vGwFKfRRyeI8YfYXg/m','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Prime','Focus Sky Monitor','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'skyprobe','Imported from LDAP',NULL),(352,'sylvain@cfht.hawaii.edu','$2y$08$FTfHtQXwl7bmptMNAFFZZOJlWSONaxn46xhgjpnxmxLCaV35tCe/a','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Sylvain','Sylvain','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sylvain','Imported from LDAP',NULL),(353,'prunet@cfht.hawaii.edu','$2y$08$ryBaL3tzNlup09MyyBhHjOxmPv94UQ0Dx1StDrUQzLkWUHu7hx/16','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Simon','Prunet','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'prunet','Imported from LDAP',NULL),(354,'moseev@cfht.hawaii.edu','$2y$08$8OmbP0mSSKzOE5Z0xsIfdOgYGHyQEQVjRgGYKG9Xw1hxPSQhP7ARi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MOS','with eev','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'moseev','Imported from LDAP',NULL),(355,'martin@cfht.hawaii.edu','$2y$08$X3PXWixx9LMDmos9OFaSUe3ub3nzc1h7qTSwYgWFHMSu78e1scTRK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Pierre','Martin','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'martin','Imported from LDAP',NULL),(356,'canleg@cfht.hawaii.edu','$2y$08$8R45RDhNbdl5oBCWMJxSO.hpZvaQN45D0M5xH0x0/KfAOVSaMApgy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Canadian','Legacy Survey Group','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'canleg','Imported from LDAP',NULL),(357,'sabin@cfht.hawaii.edu','$2y$08$yd9E9gCoOofFeNFhdcK3G.BJQdBQC7GFWIerr1ENM/i0btt7I6nlG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Dan','Sabin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sabin','Imported from LDAP',NULL),(358,'uucp@cfht.hawaii.edu','$2y$08$EIr33FXinKnC2B4f2WzjEuBz.JbM7lFUEJc5308Or2qNEPMpOVs9q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Unix','to Unix copy','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'uucp','Imported from LDAP',NULL),(359,'seup@cfht.hawaii.edu','$2y$08$zM6vLrb4JeEkm1YHSVivieAhUm0Un/s33Jm68joXvPc0sGv.2nQ9C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','Emergency User on piko','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'seup','Imported from LDAP',NULL),(360,'sne@cfht.hawaii.edu','$2y$08$aUdidP9ReI9VmjfMX7qquOn6k/t/iJXtp/8ltAJm8AYzzp2kYfM4i','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CV','Project User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sne','Imported from LDAP',NULL),(361,'ccd@cfht.hawaii.edu','$2y$08$kOLfNFNhye2GgfBIsHext.hL0Hu80lQMUCtxsURuWoQGh7uWa7aQy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CCD','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ccd','Imported from LDAP',NULL),(362,'melrose@cfht.hawaii.edu','$2y$08$TsKWIRCYA7b9GLjfnhLQQukaXJvTcjh2Y1TGWmOin1T.DGcG3Mw1C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'James','Melrose','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'melrose','Imported from LDAP',NULL),(363,'megacam@cfht.hawaii.edu','$2y$08$7vzdtzTDkprD1JYmmgv4Yeiwm3w0yfF37ELmyf/ilsLVKHpmGnSJi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MegaCam','MegaCam','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'megacam','Imported from LDAP',NULL),(364,'forshay@cfht.hawaii.edu','$2y$08$Wvl88g1h8sR9uvhjKAlHwu3PjgPpWnns09AzQ1vCbLukOXZ519KDG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Peter','Forshay','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'forshay','Imported from LDAP',NULL),(365,'maryjo@cfht.hawaii.edu','$2y$08$h5bLpaAdyefsKnuP6tSLv.oQmtk/sEinceo0FF8BShOhqwd/qFO3q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mary','Jo Link','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'maryjo','Imported from LDAP',NULL),(366,'braden@cfht.hawaii.edu','$2y$08$Zyg0xnLCkpCE6HAFzMYOQuqv0iiay6dIDEfUrwJk0x2E.iL5mUGYa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jake','Braden','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'braden','Imported from LDAP',NULL),(367,'arruda@cfht.hawaii.edu','$2y$08$0vayo9FK7Tl8MGCApJcX6uorRMU07WJM5TBxZRALPSEZyZ8sCYb2a','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tyson','Arruda','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'arruda','Imported from LDAP',NULL),(368,'kanoa@cfht.hawaii.edu','$2y$08$YkFxsFIeniCF3qOeTIlzQek6zoLxswfvYg1BmjogvgyudXIirGcfu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Kanoa','Withington','0000-00-00 00:00:00','2016-07-09 03:24:59',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kanoa','Imported from LDAP',NULL),(369,'higgs@cfht.hawaii.edu','$2y$08$ZTC4YnBuscYyDBe6wjKJx.kQ1KBPq9sRRalNaUGoX90qNNfpMtgmq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Clare','Higgs - Visiting Student -JCC','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'higgs','Imported from LDAP',NULL),(370,'green@cfht.hawaii.edu','$2y$08$lCpID1eQhFv2hDZREgY0suXLPHwAokEHMEjCyX/KXH/uD/Fq1nB.C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Greg','Green','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'green','Imported from LDAP',NULL),(371,'ward@cfht.hawaii.edu','$2y$08$h9Mb7bBpiV5clDDKh5hxXub7mNGTU4Zr06YQGjG7371WPuv0eMLgi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jeff','Ward','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ward','Imported from LDAP',NULL),(372,'tftp@cfht.hawaii.edu','$2y$08$4IC7B02B2AHSbiaoByMTJuTegL83YJl5MVsizd/qwXSJgJ8gY9c7G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TFTP','Gremlin','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tftp','Imported from LDAP',NULL),(373,'lama@cfht.hawaii.edu','$2y$08$zhkWUAZ5PJv4VeIdszeWZesRgrq0/bvHnwhyOE8LBC6TVCTpcn8De','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Laser','Machine','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lama','Imported from LDAP',NULL),(374,'jlv@cfht.hawaii.edu','$2y$08$0SrrXfN0s03TxXZilgB5J.JumQcMlRpk8Zy4EdpwaJBG3cnegAfcK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean-Louis','Villecroze','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jlv','Imported from LDAP',NULL),(375,'mailnull@cfht.hawaii.edu','$2y$08$TNfU8lyAsHoqeD21XBwP0.dc2CQ5k/Uf7.T/Nw/DfdP83TDQCSAA6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SMPro','user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mailnull','Imported from LDAP',NULL),(376,'woillez@cfht.hawaii.edu','$2y$08$orv37in2jtRbPfUAiUhNJuiM5yL1TyfScFlZdUHyyIxG75N4tHS22','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Julien','Woillez','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'woillez','Imported from LDAP',NULL),(377,'veillet@cfht.hawaii.edu','$2y$08$pRoQy77Yt636EoWhOd4zwOwND3gGyFt7rUHhtkVbKvnT/vaiWuuZO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Christian','Veillet','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'veillet','Imported from LDAP',NULL),(378,'tornado@cfht.hawaii.edu','$2y$08$dlxUhl9sM2GoTsveFuGBmecfCWJckywiHGZ1L0Ily.P7i.6PLaTLS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'VxWorks','Tornado Maintainer','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tornado','Imported from LDAP',NULL),(379,'milner@cfht.hawaii.edu','$2y$08$RrOS7bFPMdUErH87X1OxQeLGyd5O9pnLRJ51ACHQPB06hGsF/dKPa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Steve','Milner','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'milner','Imported from LDAP',NULL),(380,'akana@cfht.hawaii.edu','$2y$08$vcWGEnUf4cVy1aulXr72YuI1e/mdrfZBj3okfzfUeN.JGtyIdywCu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Moani','Akana','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'akana','Imported from LDAP',NULL),(381,'cafe@cfht.hawaii.edu','$2y$08$NH2foPQLao1clywo58mmkuBZFIjiH0wt5cJX3/neA/gccGlKrP/4O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CAFE','user','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cafe','Imported from LDAP',NULL),(382,'ftp@cfht.hawaii.edu','$2y$08$eslDebM1aDXuMsz2GkwURugWmgR2r1sL39KEvJZ4Fz9Buqt0HftYu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'FTP','Gremlin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ftp','Imported from LDAP',NULL),(383,'geminiob@cfht.hawaii.edu','$2y$08$8m1n4FZIurjaUisbpzZTbO6089VDCj59ECjlQo6vsH2xt.sKgVvv6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Gemini','Obs','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'geminiob','Imported from LDAP',NULL),(384,'mpguide@cfht.hawaii.edu','$2y$08$yusPspsUl52Hp4Nc7iRj8u1X2/BwaloK3TuDSg0IxT6SR/Ud15rj.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'MegaPrime','Guider','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mpguide','Imported from LDAP',NULL),(385,'ftaclas@cfht.hawaii.edu','$2y$08$VcoGIDr3pw4AtRL51E2Bfe2sxq6wHP2WV4WVUKZHdI4U29SdqTRPq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Christ Ftaclas','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ftaclas','Imported from LDAP',NULL),(386,'nguyen@cfht.hawaii.edu','$2y$08$OUdLNvucCWuLXfxtc1YZ2ee1prpwNohg9y/SLpLooG18S8e0vJJDy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tien','Nguyen','0000-00-00 00:00:00','2016-07-09 03:25:21',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'nguyen','Imported from LDAP',NULL),(387,'lihwai@cfht.hawaii.edu','$2y$08$wAaxoDsPC9wj523kpMdc7.vqIuOBlUL66T97y3r6hva8uaao9NlwG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Lihwai','Lin','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lihwai','Imported from LDAP',NULL),(388,'eugene@cfht.hawaii.edu','$2y$08$KRo5CEUShxbhL4teSL8iGuV1AtPFPSRuGwQD0o76bprWGbxsn47Lq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Eugene','Magnier','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'eugene','Imported from LDAP',NULL),(389,'cfhtls@cfht.hawaii.edu','$2y$08$mLtWQ83tVy2aNGZocTGU4exxDUv4JUsSVJ6NU/Zec3D2AUWjzsQI6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHT','Legacy Survey','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cfhtls','Imported from LDAP',NULL),(390,'chyan@cfht.hawaii.edu','$2y$08$qinu9l544dbOSKHeKEmSC.htSZ97PSL.gyoZmlLxIK6KVcJm5mhzG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Chi-Hung','Yan','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'chyan','Imported from LDAP',NULL),(391,'ccdwm@cfht.hawaii.edu','$2y$08$Rkmvzp7ikXGGTWmINAdbbusFF5eeabnQWM99ZeBS0cSEltLqObPyG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Waimea','CCD on mimas','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ccdwm','Imported from LDAP',NULL),(392,'erg4@cfht.hawaii.edu','$2y$08$W3DPxx4zWWTiuPQvrrvHKuqlHa0A599jSntzSIiVW3LRJyQFrLpcC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ernesto','Grundseth','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'erg4','Imported from LDAP',NULL),(393,'cabreira@cfht.hawaii.edu','$2y$08$QFZCLi6Q6ZSQPYydYkeA0e63V891TrX/uV22LeBerR6On93dmdguu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Brian','Cabreira','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cabreira','Imported from LDAP',NULL),(394,'reticon@cfht.hawaii.edu','$2y$08$teHvrSicJj5eXLhDlAK9kuggNGRdW3jkkHJU8HpoHdKOo/WRWiALO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Reticon','Instrument','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'reticon','Imported from LDAP',NULL),(395,'massey@cfht.hawaii.edu','$2y$08$FrMHYkh0Sojg6Buvk2cwr.YcV/v4gIvDtajzqltAnsVbTM6/6LJ5O','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Steve','Massey','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'massey','Imported from LDAP',NULL),(396,'kuntz@cfht.hawaii.edu','$2y$08$nYC9NHpCB6FcTmjvqM4VRe7hLFEgsQDqCD7p3GZYiEgIuWl4UCnbe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Adrien','Kuntz','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kuntz','Imported from LDAP',NULL),(397,'bernt@cfht.hawaii.edu','$2y$08$TOel65dl6AM8P38FVEifHu0DnlyaajXZgS9khDmZA5kFeictG/zSG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Bernt','Grundseth','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bernt','Imported from LDAP',NULL),(398,'iraf@cfht.hawaii.edu','$2y$08$GHWcfgXPvtAMu8yncjgN9Ot.Zz16oPwG0G/Q4fQ69bbeVCJw4X942','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'IRAF','Guru','0000-00-00 00:00:00','2016-07-09 03:25:32',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'iraf','Imported from LDAP',NULL),(399,'gillian@cfht.hawaii.edu','$2y$08$rbtttV3dx0VDGzOHHWZleeljFnkZm6vpig1KE5QeB1LH9S8BzaQwm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Gillian','Rambold','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gillian','Imported from LDAP',NULL),(400,'cordero@cfht.hawaii.edu','$2y$08$1jy54f53EPGiFLY4kNDMh.vhukKGWwHqS9PptqaD66/d0tnlgR2dq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Olga','I. Cordero-Brana','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cordero','Imported from LDAP',NULL),(401,'cfh12kb@cfht.hawaii.edu','$2y$08$i7IJ0EOllOGGJwWE2rozfeU/d3OKf.CPIfYPIYmTy0Mak.z9v.m06','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'12Kx8K','Mosaic Camera','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cfh12kb','Imported from LDAP',NULL),(402,'arnouts@cfht.hawaii.edu','$2y$08$sVNR8lpgDICBJcXbIoYMlupWCT0zSapEb3befwiNflvzrTlPArmaO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Stephane','Arnouts','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'arnouts','Imported from LDAP',NULL),(403,'osisir@cfht.hawaii.edu','$2y$08$sj5ImMdPAZcz8RBqfQJWS.FZiz8QIZombkAOIPLsWaTeZTSdlozGK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHT','IR with OSIS','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'osisir','Imported from LDAP',NULL),(404,'gnuadm@cfht.hawaii.edu','$2y$08$ZSMpoTWDxO1qooes6873rOSIfVvnrTejSqPelOEXloJaAbdmSv2LC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Gnu','is Not Unix','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gnuadm','Imported from LDAP',NULL),(405,'flagey@cfht.hawaii.edu','$2y$08$saJNJTM4xBvBZLSR2mIAn.sXxSXTHQc.yb7Gj3/qx0vOeYOPwg06e','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Nicolas','Flagey','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'flagey','Imported from LDAP',NULL),(406,'cfh12k@cfht.hawaii.edu','$2y$08$d2wcSGPOSeAcvwPYLceaHuDI9OA..vAQ0.f9lTkTIGunV8JgbGqPG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'12Kx8K','Mosaic Camera','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cfh12k','Imported from LDAP',NULL),(407,'malia@cfht.hawaii.edu','$2y$08$5J0j9n0FyeWVhbFSCaekUOIt2fufg/oMq86QFyMrG3sE8JHnIJBji','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Malia','Mallchok','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'malia','Imported from LDAP',NULL),(408,'ptolemy3@cfht.hawaii.edu','$2y$08$uJt9HqBtupCM0jlnZMip0O9cF7S4vnu5Te4eIZ1qJP1.YTgRHq8fm','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Opera','user','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ptolemy3','Imported from LDAP',NULL),(409,'dadsmail@cfht.hawaii.edu','$2y$08$694UvONRAGKS7gPZ5fX8f.XIWJhqvRuDJxPZ.ySZ7gnVpgN6gZQ5K','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'DADS','Mail','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dadsmail','Imported from LDAP',NULL),(410,'sysdiag@cfht.hawaii.edu','$2y$08$wH2cHtWKHl2X36kwOvAjKuDsHZL02xkisbSn1R43CTbcFQoWpLzIe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'System','Diagnostic','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sysdiag','Imported from LDAP',NULL),(411,'soucail@cfht.hawaii.edu','$2y$08$MM4KcEHwzap81N7Hno9t6e6NBtHMZyFYB1EXotvuhNgXYNyN8nXuO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Genevieve Soucail','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'soucail','Imported from LDAP',NULL),(412,'osiseev@cfht.hawaii.edu','$2y$08$UJv9hkg6x7vXyvIOkgkIDeq10erIcP9i3QxidN6Y92wzWXGMnPK3G','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'CFHT','eev with OSIS','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'osiseev','Imported from LDAP',NULL),(413,'remweb@cfht.hawaii.edu','$2y$08$5hfw4ZUwitolbNU3Gh1Q8e8g0WuuFz7YXNCXJDXUT1CY4kp49QWwC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Remedy','Web CGI','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'remweb','Imported from LDAP',NULL),(414,'morton@cfht.hawaii.edu','$2y$08$gqDfRE82HsvF50BDNChxJuUgDLPV5kib.QwdgVZZ7rpE/CuUySpEO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Don','Morton','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'morton','Imported from LDAP',NULL),(415,'hooper@cfht.hawaii.edu','$2y$08$3D2Uhpaopq6CvwaJBtdnVeYZ6weCM8VJ9IIlRawF/VhpIEYSVhZXa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'David','Hooper','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hooper','Imported from LDAP',NULL),(416,'fehly@cfht.hawaii.edu','$2y$08$HTJjDC6Sn4JXGZQem2hfneEVjx4mfv8A3B1lVTXFH4UjTAoOua01m','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Joseph','Fehly','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fehly','Imported from LDAP',NULL),(417,'tomv@cfht.hawaii.edu','$2y$08$mOMTztIylLZN6zbiFmufHuHfuEC.9fKexXql8WkhWUjdcmmujlIF2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tom','Vermeulen','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tomv','Imported from LDAP',NULL),(418,'trg@cfht.hawaii.edu','$2y$08$rqohSnAR558QOfGsGgkxBOdpKw4k7JCZWAGBEx4kzDG/eWM14tLWq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Teddy','George','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'trg','Imported from LDAP',NULL),(419,'tic@cfht.hawaii.edu','$2y$08$Dbg241yIZvE45eHZWQJXS.2q35INHxwlYztGmQa9G/rkd97Oe/T/a','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'TIC','user for instrument exchanges','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'tic','Imported from LDAP',NULL),(420,'hrc@cfht.hawaii.edu','$2y$08$t7W0RlDoFuoxVyiJAOABeu603KRDm5YW67aDnev.j4raxWuSHTxwq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'High','Resolution Camera','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hrc','Imported from LDAP',NULL),(421,'canleg4@cfht.hawaii.edu','$2y$08$cIsM9FJ1HhGsYqjaF3QXpuXff1qtEDItci8ZUDdXdwqXegfOxu0Ha','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Canadian','Legacy Survey Group','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'canleg4','Imported from LDAP',NULL),(422,'donati@cfht.hawaii.edu','$2y$08$7wnMTNG00LGMu2QEkGYtEO5atr0D7/HeJsYgTrGJAzqqXWzveqBvu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Donati','Donati','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'donati','Imported from LDAP',NULL),(423,'delage@cfht.hawaii.edu','$2y$08$JUoTSxdAedy8DX2gwPNZSeQ/NhznrTBWEwdSUyCl/0Sn0ad8rNtmO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Raphael','Delage','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'delage','Imported from LDAP',NULL),(424,'ccdwc@cfht.hawaii.edu','$2y$08$hpc9nAcsOu45jCQdFeQxduZxiEscGMA27ceo7EIe4pveVoQESV4gO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Waimea','CCD on cassini','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ccdwc','Imported from LDAP',NULL),(425,'lai@cfht.hawaii.edu','$2y$08$76cjm8WbvSsO9E6D2YNqrem78cO9Jh.7gYFXu7mVj9LnsKJ.b4TgO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Olivier','Lai','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'lai','Imported from LDAP',NULL),(426,'carignan@cfht.hawaii.edu','$2y$08$sJ7xqg9raYno0imZXl5L4uhaaY6NSrz.2KSosaA5/vTIB4a5Pztdq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Claude','Carignan','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'carignan','Imported from LDAP',NULL),(427,'berthoud@cfht.hawaii.edu','$2y$08$cb98oEh1b9joxdLEz7W61ulQVoZUrZr5JtZLpAwt5pvj4uvDKqP3C','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Claude','Berthoud','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'berthoud','Imported from LDAP',NULL),(428,'benedict@cfht.hawaii.edu','$2y$08$TAb2woRNCWPmF9CaR37dj.OcILezo4Jz92xqDnKU3fUeaft0C29pu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Tom','Benedict','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'benedict','Imported from LDAP',NULL),(429,'qsocron@cfht.hawaii.edu','$2y$08$JPxstSLBrdGr8hp4HZEqgOsYJQNmzPZcy7ytOtwOVij1Ph0psjw9.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'QSO','backup cron jobs','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'qsocron','Imported from LDAP',NULL),(430,'monitor@cfht.hawaii.edu','$2y$08$HNkJeOiNZl3VWmjZns6VdO4gzKgI7AEGguxsW3i9nUA/aDdzmBN66','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Status','Server monitor user','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'monitor','Imported from LDAP',NULL),(431,'wilcox@cfht.hawaii.edu','$2y$08$qxBOQGTi65pfgex2g1PzDOK6AG8J2WlohLVTW3x4rirajrFqHDcBa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Dan','Wilcox','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wilcox','Imported from LDAP',NULL),(432,'jamey@cfht.hawaii.edu','$2y$08$49DfM47EF6qjdM5yLnKoy.vE36ytdDu4sXFKaM2gRvNjnYwcdOXGi','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jamey','Eriksen','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jamey','Imported from LDAP',NULL),(433,'cross@cfht.hawaii.edu','$2y$08$ps7PdxTgUA6u63MubxQrQu/Nh6bEjxcZX/IldbHUU4uNFYvAT0wAW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Katherine','Cross','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'cross','Imported from LDAP',NULL),(434,'chris@cfht.hawaii.edu','$2y$08$titvHV5nLVTJW4U4r3ehDO.zYAVYHpM0SwjqRT9RXhnKYD.xoB7em','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Chris','Clark','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'chris','Imported from LDAP',NULL),(435,'sydserff@cfht.hawaii.edu','$2y$08$JI7p9DelzDRcMxnzHOSaYuGl8LNWmHA3qY7/ZBj4DJxoK54Tw4y7e','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Peter','Sydserff','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sydserff','Imported from LDAP',NULL),(436,'jhfarmer@cfht.hawaii.edu','$2y$08$EzoQlyd7uLoNXkh4cZECqu6zflbvO57rgRIC7I3fcmC2zxYwR0aSO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jennifer','Haywood-Farmer Baril','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'jhfarmer','Imported from LDAP',NULL),(437,'rousset@cfht.hawaii.edu','$2y$08$VCHmAiA89XxS6inMtLR34uUDYTnFccBGdi4wq0XbTq04vwWN/PJ0.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Arlette','Rousset','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rousset','Imported from LDAP',NULL),(438,'fahlman@cfht.hawaii.edu','$2y$08$soQ07NUPihZmF55eA3AI2O0XCjtZbKBE0lglSeHSqwPdGUr5tH8Cq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Gregory','Fahlman','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'fahlman','Imported from LDAP',NULL),(439,'whwang@cfht.hawaii.edu','$2y$08$Y3Z4ehT9qUSH1m4k8zrTOO7SdjwHuVBz8uhDGfV5m2fmSoHHzgkt6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Wei-Hao','Wang','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'whwang','Imported from LDAP',NULL),(440,'xerox@cfht.hawaii.edu','$2y$08$g3d2LaSWSYo4agswPQlmXuzmqSzFLv25tfmVvoYJQVUY2qtgO3Td.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Xerox','ftp user','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'xerox','Imported from LDAP',NULL),(441,'gnats@cfht.hawaii.edu','$2y$08$x3n6ePn7ctzWm4mQ2s6TpuOuEvGbhclqVbwryaR9F7gX.8rXcM6PO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'GNATS','User','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gnats','Imported from LDAP',NULL),(442,'urep@cfht.hawaii.edu','$2y$08$u3AqzkY0APn1ueHch1BiPO2VBGV43ago3b1gl4ctOdtlKtK815C.q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'RSCS','BITNET emulation','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'urep','Imported from LDAP',NULL),(443,'sarchlok@cfht.hawaii.edu','$2y$08$8CLuGzlmcjnyE5ergd13dOfx0x84wwf3MteWBbGOOY/nq6lChpz0i','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Summit','archive user on lokahi','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sarchlok','Imported from LDAP',NULL),(444,'wallace@cfht.hawaii.edu','$2y$08$1bgqB18meWEsDmI25Hy8BuCYistHPk59BR1bBFgROUrdd9djLTmLy','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'William','Wallace','0000-00-00 00:00:00','2016-07-09 02:17:57','2016-07-09 02:17:57',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wallace','Imported from LDAP',NULL),(445,'bourlon@cfht.hawaii.edu','$2y$08$1R28kr3XqUUD2ATnKGfHSePGRVm1yRQQgJH47Xt63zXDg0Wdj3p2.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Philippe','Bourlon','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'bourlon','Imported from LDAP',NULL),(446,'berthod@cfht.hawaii.edu','$2y$08$U30dfaqzVMUnQwTOUkuuq.01se3HjtchSBiyZ4E9AyfIY3bclGM6S','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Christophe','Berthod','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'berthod','Imported from LDAP',NULL),(447,'mizuba@cfht.hawaii.edu','$2y$08$dcijlzpFunyAo95RJsAd9eI7PxO3u9nacwRNyG1JHnbXhVn8E4o12','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Les','Mizuba','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mizuba','Imported from LDAP',NULL),(448,'szeto@cfht.hawaii.edu','$2y$08$iRdAWv8c8iC03DOtQUlOleaHlYZOsonG1G.jIXBVONP5gfEJyFJPe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Kei','Szeto','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'szeto','Imported from LDAP',NULL),(449,'hikim@cfht.hawaii.edu','$2y$08$x0MfcdX5HwQKCD789YYqHeRGQAvYFFM4/BH8ZQ.WJXxg5BZ6NJ5B2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Korean','RA','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hikim','Imported from LDAP',NULL),(450,'aobir@cfht.hawaii.edu','$2y$08$GqL5F1iCCxqHY2y3RsSJz..WXO1diSv5d7hO1kL9LWUHhTVl7t7Za','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'AOB','with KIR','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'aobir','Imported from LDAP',NULL),(451,'dimm@cfht.hawaii.edu','$2y$08$iTMQ4FuSGcmlhRnYA6QDK.EU.mF1VnveZY4BKmuMM/Or6gaR9pGLa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'DIMM','user','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'dimm','Imported from LDAP',NULL),(452,'petitjean@cfht.hawaii.edu','$2y$08$qK2ucS9V8w7KrmQi0beoA.DIAzG8QderXOVc6uvqMLjoixWHxUEFq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SAC','Patrick Petitjean','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'petitjean','Imported from LDAP',NULL),(453,'rieutord@cfht.hawaii.edu','$2y$08$VoHQCKDLgHrfalPTL8xkbuF.zsm5bnbv6SZEpIUMiSUFYu8Y8c1w.','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Michel','Rieutord','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rieutord','Imported from LDAP',NULL),(454,'kauelaar@cfht.hawaii.edu','$2y$08$TxpETlH2DLJHvhnDkq8qzuwuJBiRkvJOuzZSBGN306u72N4bxwyFS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'JJ','Kavelaars','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'kauelaar','Imported from LDAP',NULL),(455,'wburkey@cfht.hawaii.edu','$2y$08$9CYAj1RqOMt6hmGXFgp2auIPe18BLlw6u0tcKx7Z8Jyn8ET6Uplge','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Billy','Burkey','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wburkey','Imported from LDAP',NULL),(456,'neoserv@cfht.hawaii.edu','$2y$08$AW3jd3U4wOYHpalK8Ajw9OBi0Nib34uUAxNUh8DSgCYorZrhXduES','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'NEO','server user','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'neoserv','Imported from LDAP',NULL),(457,'gorceix@cfht.hawaii.edu','$2y$08$SlkZqVD46ufKNh4OxA570OwSZh8xyTEdjRvKHn23l7/uynznYPRne','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'French','cooperant Nicolas Gorceix','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'gorceix','Imported from LDAP',NULL),(458,'canleg2@cfht.hawaii.edu','$2y$08$W45eFJ3WsLlRp6wM92Ju5erbEsIQkj0TYubJ0dbGMr1emHqRIMurS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Canadian','Legacy Survey Group','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'canleg2','Imported from LDAP',NULL),(459,'sisfp@cfht.hawaii.edu','$2y$08$a2q3Fz8A6Or9Ws2D3tNQPOP5skg4jDc74sAVN5gKkSvIotIBcibNe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SIS,','Fabry Perot','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sisfp','Imported from LDAP',NULL),(460,'spi@cfht.hawaii.edu','$2y$08$TtFru6ji0LVZ22ARx3QWEOeeXG7sMwgiH5gP8HNFonLRbdiXCkppK','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'SPI','SPI','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'spi','Imported from LDAP',NULL),(461,'oat@cfht.hawaii.edu','$2y$08$QorizMJ7ktRLEohsXA91R.HADdW8MZmnVIjSm6NLwqo3YtH9LILNC','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'OA','Test Account','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'oat','Imported from LDAP',NULL),(462,'mdevost@cfht.hawaii.edu','$2y$08$4dG5WcG2J2p0QW98IyZAIeOt.RBbun8T5nrcgtvvXv2V73szSWaeW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Michelle','Devost','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'mdevost','Imported from LDAP',NULL),(463,'iaucirc@cfht.hawaii.edu','$2y$08$2IU9ZWyj0CDpwPEmEvGIPuoY/wFvaIqPiMfWCTNcm22aH30MRUrvW','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'IAU','Destination','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'iaucirc','Imported from LDAP',NULL),(464,'zelman@cfht.hawaii.edu','$2y$08$JxMT68BNOIsjeWquWx5YbOi3dr3mKU2X6lIsk5lLPqxJWRMLTX5lS','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Rachael','Zelman','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'zelman','Imported from LDAP',NULL),(465,'wipper@cfht.hawaii.edu','$2y$08$BFohNTwJg97HTq2JdYabEuZ1T.jvA2LKbbuZspIkFI9eejLB2yMjO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Cam','Wipper','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'wipper','Imported from LDAP',NULL),(466,'osisfp@cfht.hawaii.edu','$2y$08$jlVA8yL41B5W89YnTN22deW0DWe75vtBbRf8MjK3NIfOQeBAtpujq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'OSISFP','OSISFP','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'osisfp','Imported from LDAP',NULL),(467,'weber@cfht.hawaii.edu','$2y$08$rHmx8EESa4iJc5usMaV9u.VxfvlLdtLJj.On2UWG49rc.GCR84GRq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Mark','Weber','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'weber','Imported from LDAP',NULL),(468,'osisr@cfht.hawaii.edu','$2y$08$GRbLsoWRonGiFOJTvsrQF.S1pogrLjY3vb9glo.fnSqyXfD7XuT4u','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'OSIS','OSIS','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'osisr','Imported from LDAP',NULL),(469,'grb@cfht.hawaii.edu','$2y$08$RL9I4x5wnfyh4zUl678oseZh0Yocu.lF2ni55Zf8HtKCPW.w5TRy2','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'French','GRB project','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'grb','Imported from LDAP',NULL),(470,'p3@cfht.hawaii.edu','$2y$08$p0Wu2WTGrYbfcu5K63VQDebPiahWgqVhd7OcD.gI1TzBfqXBupZwG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'P3','User','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'p3','Imported from LDAP',NULL),(471,'owncloudadmin@cfht.hawaii.edu','$2y$08$YZsLpXU2Q5rkxAzp36OKAuLIA1W.QWTJlZui5rTIVx6BU2ofg4Mbq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Own','Cloud','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'owncloudadmin','Imported from LDAP',NULL),(472,'git@cfht.hawaii.edu','$2y$08$OmkCyuF439TABVFNNXx8zetSFmU65rjAr0zEzzpdZMbEdMcoG0DUe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'git','user','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'git','Imported from LDAP',NULL),(473,'pfsenseadmin@cfht.hawaii.edu','$2y$08$BJryD97KdJF4lCoExBlYuOtXfUOD8BPmMjEo4kB..940NO8AjRROq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'pfsense','admin','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'pfsenseadmin','Imported from LDAP',NULL),(474,'apachestudioadmin@cfht.hawaii.edu','$2y$08$BXzq95jCcFsTfWh6mA56dev23mSXsQ5rFS5hI4nAuaLH5gk2KShoa','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'apache studio','admin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'apachestudioadmin','Imported from LDAP',NULL),(475,'confluenceadmin@cfht.hawaii.edu','$2y$08$zBgl4dZrg10JPS9IKmYOrOww.R31ZnqMT80fSmK0OXPOyF9kEr2xe','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Confluence','Admin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'confluenceadmin','Imported from LDAP',NULL),(476,'jean-yves.rousse@cea.fr','$2y$08$vfsMfQIjXTy5HRBJgSxr7.843HFjrpTngA05dLJqOMr379RVatR5q','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Jean Yves','Rousse','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'rousse','Imported from LDAP',NULL),(477,'venus@cfht.hawaii.edu','$2y$08$fh4i8tGUQzYi6gSpGT8EBeQU/sgPim3x.X0w7Cy9CmGOahhl5f2WO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Venus','Team','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'venus','Imported from LDAP',NULL),(478,'venus2@cfht.hawaii.edu','$2y$08$nodKLQPWOyOsgXeuNBKcSOWKVQo6uiND/4ZNbprGlIYkp7LVCUrB6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'venus','venus','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'venus2','Imported from LDAP',NULL),(479,'freenasadmin@cfht.hawaii.edu','$2y$08$hSKxp1uRwS4bSx8ffzexn.1AG8hcdKrSOJ4o2YS5reYBnDYGc0xV6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'FreeNAS','Admin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'freenasadmin','Imported from LDAP',NULL),(480,'babas2@cfht.hawaii.edu','$2y$08$x3GBaVU2ATCEg25MnCqQVOaz0lzDL86Xf3mtOMiQriJBtlvQCyKJq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Ferd','Babas','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'babas2','Imported from LDAP',NULL),(481,'hughes@cfht.hawaii.edu','$2y$08$9cWo4CPEXB4LxBlxOdPLCu0ivPZKFzlYw5CpvMILQSwhEt/RlfBDO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Steve','Hughes','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'hughes','Imported from LDAP',NULL),(482,'thronas@cfht.hawaii.edu','$2y$08$D0MT8fsWPKdqpmnktGgZAuBGBhT80xWiTJMVCkoOJMbDf/O5nq.We','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'James','thronas','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'thronas','Imported from LDAP',NULL),(483,'ganetiadmin@cfht.hawaii.edu','$2y$08$KjLAPVuqBN67raSAxVQsluX0qUQ4UnnEkZcf5/PbT8ULZbfbEGQny','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'ganetiadmin','ganetiadmin','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'ganetiadmin','Imported from LDAP',NULL),(484,'petric@cfht.hawaii.edu','$2y$08$Zl5PsZRi4JwSnotzeUKfguAM32bU5wQ3PIVwhj.VmijlapHm/D1mO','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Andreea','Petric','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'petric','Imported from LDAP',NULL),(485,'romy@cfht.hawaii.edu','$2y$08$6bxDrCD5jhvBNMziQOqZzOsixRyKydsbqhXjNTiabDvktWzb5Cntu','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Romilly','Benedict','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'romy','Imported from LDAP',NULL),(486,'testuser1@cfht.hawaii.edu','$2y$08$I3YsFD1mjFWdoCA3xyqwm.cX24XdXNvvuZLVnffY24ncxqMP.rnrG','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Test','User1','0000-00-00 00:00:00','2016-07-09 02:17:47','2016-07-09 02:17:47',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'testuser1','Imported from LDAP',NULL),(487,'sayco@cfht.hawaii.edu','$2y$08$F32Nq2VGn4TBy5ejDxyzR.sUyGOG4zMBOajS1NtbAiVqcQ8kOTeDq','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Arturo','Sayco','0000-00-00 00:00:00','2016-07-09 02:17:12','2016-07-09 02:17:12',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'sayco','Imported from LDAP',NULL),(488,'operguest@cfht.hawaii.edu','$2y$08$2IcXamEsGWrb6zyw71gESuYXaULSlNk5CuXIZ01vI8f.PWSgmnSl6','{\"user\":1}',1,NULL,NULL,NULL,NULL,NULL,'Operations','Guest','0000-00-00 00:00:00','2016-07-09 02:17:36','2016-07-09 02:17:36',NULL,NULL,NULL,1,NULL,NULL,NULL,'',NULL,'operguest','Imported from LDAP',NULL),(489,'','$2y$08$hymBL8PDYONagWx7p3b14uDWYhmWk/2iFTwXLk9SGf6RZa4Qs1MQG','{\"user\":1}',1,NULL,NULL,'2016-07-09 02:58:21','$2y$08$wyzKRbjRUt9ddue7ffmP5.1HpBxJxgOOzpk10duJTwdndjjjXDtvG',NULL,'','','2016-07-09 02:58:21','2016-07-09 03:02:01','2016-07-09 03:02:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,'akamai','Imported from LDAP',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (2,1);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-08 17:29:00
