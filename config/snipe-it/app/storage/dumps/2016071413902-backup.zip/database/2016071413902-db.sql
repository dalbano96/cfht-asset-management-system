-- MySQL dump 10.14  Distrib 5.5.47-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: cfht_snipeit
-- ------------------------------------------------------
-- Server version	5.5.47-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accessories`
--

DROP TABLE IF EXISTS `accessories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `requestable` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) DEFAULT NULL,
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessories`
--

LOCK TABLES `accessories` WRITE;
/*!40000 ALTER TABLE `accessories` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accessories_users`
--

DROP TABLE IF EXISTS `accessories_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessories_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accessories_users`
--

LOCK TABLES `accessories_users` WRITE;
/*!40000 ALTER TABLE `accessories_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `accessories_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_logs`
--

DROP TABLE IF EXISTS `asset_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `asset_id` int(11) DEFAULT NULL,
  `checkedout_to` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `asset_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  `filename` text COLLATE utf8_unicode_ci,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `requested_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `accessory_id` int(11) DEFAULT NULL,
  `accepted_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `expected_checkin` date DEFAULT NULL,
  `thread_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_logs_thread_id_index` (`thread_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_logs`
--

LOCK TABLES `asset_logs` WRITE;
/*!40000 ALTER TABLE `asset_logs` DISABLE KEYS */;
INSERT INTO `asset_logs` VALUES (1,12,'requested',3,NULL,NULL,'2016-07-11 08:51:12','hardware',NULL,NULL,'2016-07-11 18:51:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,12,'requested',3,NULL,NULL,'2016-07-11 08:53:42','hardware',NULL,NULL,'2016-07-11 18:53:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `asset_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_maintenances`
--

DROP TABLE IF EXISTS `asset_maintenances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_maintenances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL,
  `supplier_id` int(10) unsigned NOT NULL,
  `asset_maintenance_type` enum('Maintenance','Repair','Upgrade') COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_warranty` tinyint(1) NOT NULL,
  `start_date` date NOT NULL,
  `completion_date` date DEFAULT NULL,
  `asset_maintenance_time` int(11) DEFAULT NULL,
  `notes` longtext COLLATE utf8_unicode_ci,
  `cost` decimal(10,2) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_maintenances`
--

LOCK TABLES `asset_maintenances` WRITE;
/*!40000 ALTER TABLE `asset_maintenances` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_maintenances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset_uploads`
--

DROP TABLE IF EXISTS `asset_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_uploads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `asset_id` int(11) NOT NULL,
  `filenotes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset_uploads`
--

LOCK TABLES `asset_uploads` WRITE;
/*!40000 ALTER TABLE `asset_uploads` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset_uploads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `asset_tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `model_id` int(11) NOT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) NOT NULL DEFAULT '0.0000',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `image` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `physical` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `warranty_months` int(3) DEFAULT NULL,
  `depreciate` tinyint(1) NOT NULL DEFAULT '0',
  `supplier_id` int(11) DEFAULT NULL,
  `requestable` tinyint(4) NOT NULL DEFAULT '0',
  `rtd_location_id` int(11) DEFAULT NULL,
  `accepted` enum('pending','accepted','rejected') COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_checkout` datetime DEFAULT NULL,
  `expected_checkin` date DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  `_snipeit_qr_code_url` text COLLATE utf8_unicode_ci,
  `_snipeit_year` text COLLATE utf8_unicode_ci,
  `_snipeit_hostname` text COLLATE utf8_unicode_ci,
  `_snipeit_model_chassis_backplane` text COLLATE utf8_unicode_ci,
  `_snipeit_motherboard` text COLLATE utf8_unicode_ci,
  `_snipeit_ram` text COLLATE utf8_unicode_ci,
  `_snipeit_storage` text COLLATE utf8_unicode_ci,
  `_snipeit_role` text COLLATE utf8_unicode_ci,
  `_snipeit_cpu` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (1,'','CFHT-1',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-11 18:21:43','2016-07-11 18:33:39',1,NULL,1,0,NULL,0,NULL,0,1,NULL,NULL,NULL,1,'https://inventory.cfht.hawaii.edu/hardware/1/view','2013','mjolnir','Chassis CSE-815TQ-R700UB Backplane SAS 815TQ','X8DTU','8G','3ware 9650SE-4LPML 4 x 1TB Seagate SATA in RAID 5 1 x 2 slots network card (not used)','VMware ESXi production #4 For Ferd','1 x E5506 2.1 Ghz'),(2,'','CFHT-2',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-11 18:44:49','2016-07-11 18:44:49',1,NULL,1,0,NULL,0,0,0,1,NULL,NULL,NULL,1,'https://inventory.cfht.hawaii.edu/hardware/2/view','2013','midgard','Model 815-6 (model 6017R-WRF)','X9DRW','22G','3ware 9650SE-4LPML 4 x 2TB Seagate SATA in RAID 5 1 x 2 slots network card','VMware ESXi production #3 Bought by the Operations Group. Priority to Vault Windows VMs In network 81','2 x E5-2620 2.00Ghz 6 cores each 12 cores total'),(3,'','CFHT-3',1,'',NULL,0.0000,'',NULL,'',NULL,1,'2016-07-11 18:46:01','2016-07-11 18:50:53',1,NULL,1,0,NULL,0,NULL,1,1,NULL,NULL,NULL,1,'https://inventory.cfht.hawaii.edu/hardware/3/view','2013','freenas02','Model 815-6 (model 6017R-WRF)','X9DRW','8G','3ware 9650SE-4LPML 4 x 2TB in RAID 5','FreeNAS-8.3.0-RELEASE-p1-x64 (r12825)  freenas01 backup','2 x E5-2609 2.40Ghz 4 cores each 8 cores total');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `eula_text` longtext COLLATE utf8_unicode_ci,
  `use_default_eula` tinyint(1) NOT NULL DEFAULT '0',
  `require_acceptance` tinyint(1) NOT NULL DEFAULT '0',
  `category_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'asset',
  `checkin_email` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Laptops','2016-06-28 17:55:41','2016-06-28 17:55:41',1,NULL,NULL,0,0,'asset',0),(2,'Desktops','2016-06-28 17:55:41','2016-06-28 17:55:41',1,NULL,NULL,0,0,'asset',0),(3,'Tablets','2016-06-28 17:55:41','2016-06-28 17:55:41',1,NULL,NULL,0,0,'asset',0),(4,'Phones','2016-06-28 17:55:41','2016-06-28 17:55:41',1,NULL,NULL,0,0,'accessory',0),(5,'Monitors','2016-06-28 17:55:41','2016-06-28 17:55:41',1,NULL,NULL,0,0,'accessory',0),(6,'Printer Ink','2016-06-28 17:55:41','2016-06-28 17:55:41',1,NULL,NULL,0,0,'consumable',0),(7,'Servers','2016-07-11 18:15:21','2016-07-11 18:15:21',1,NULL,'',0,0,'asset',0);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Canada France Hawaii Telescope','2016-07-11 18:13:42','2016-07-11 18:13:42');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumables`
--

DROP TABLE IF EXISTS `consumables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `requestable` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) DEFAULT NULL,
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumables`
--

LOCK TABLES `consumables` WRITE;
/*!40000 ALTER TABLE `consumables` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumables_users`
--

DROP TABLE IF EXISTS `consumables_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consumables_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `consumable_id` int(11) DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumables_users`
--

LOCK TABLES `consumables_users` WRITE;
/*!40000 ALTER TABLE `consumables_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `consumables_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_field_custom_fieldset`
--

DROP TABLE IF EXISTS `custom_field_custom_fieldset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_custom_fieldset` (
  `custom_field_id` int(11) NOT NULL,
  `custom_fieldset_id` int(11) NOT NULL,
  `order` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_field_custom_fieldset`
--

LOCK TABLES `custom_field_custom_fieldset` WRITE;
/*!40000 ALTER TABLE `custom_field_custom_fieldset` DISABLE KEYS */;
INSERT INTO `custom_field_custom_fieldset` VALUES (1,1,1,0),(3,2,1,0),(4,2,2,0),(5,2,3,0),(6,2,4,0),(7,2,5,0),(8,2,6,0),(9,2,7,0),(10,2,8,0),(4,3,1,0),(3,3,2,0),(5,3,3,0),(6,3,4,0),(7,3,5,0),(8,3,6,0),(9,3,7,0),(10,3,8,0),(4,5,1,0),(3,5,2,0),(5,5,3,0),(6,5,4,0),(7,5,5,0),(8,5,6,0),(9,5,7,0),(10,5,8,0),(4,6,1,0),(3,6,2,0),(5,6,3,0),(6,6,4,0),(11,6,5,0),(8,6,6,0),(9,6,7,0),(10,6,8,0);
/*!40000 ALTER TABLE `custom_field_custom_fieldset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fields`
--

DROP TABLE IF EXISTS `custom_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `format` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `element` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fields`
--

LOCK TABLES `custom_fields` WRITE;
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT INTO `custom_fields` VALUES (2,'QR Code URL','','text','2016-07-11 18:14:36','2016-07-11 18:14:36',1),(3,'Year','','text','2016-07-11 18:16:44','2016-07-11 18:16:44',1),(4,'Hostname','','text','2016-07-11 18:16:54','2016-07-11 18:16:54',1),(5,'Model/Chassis/Backplane','','text','2016-07-11 18:17:08','2016-07-11 18:17:08',1),(6,'Motherboard','','text','2016-07-11 18:17:15','2016-07-11 18:17:15',1),(8,'RAM','','text','2016-07-11 18:17:31','2016-07-11 18:17:31',1),(9,'Storage','','text','2016-07-11 18:17:37','2016-07-11 18:17:37',1),(10,'Role','','text','2016-07-11 18:17:46','2016-07-11 18:17:46',1),(11,'CPU','','text','2016-07-11 18:31:43','2016-07-11 18:31:43',1);
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_fieldsets`
--

DROP TABLE IF EXISTS `custom_fieldsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_fieldsets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_fieldsets`
--

LOCK TABLES `custom_fieldsets` WRITE;
/*!40000 ALTER TABLE `custom_fieldsets` DISABLE KEYS */;
INSERT INTO `custom_fieldsets` VALUES (6,'Server Components','2016-07-11 18:31:52','2016-07-11 18:31:52',1);
/*!40000 ALTER TABLE `custom_fieldsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depreciations`
--

DROP TABLE IF EXISTS `depreciations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depreciations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `months` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depreciations`
--

LOCK TABLES `depreciations` WRITE;
/*!40000 ALTER TABLE `depreciations` DISABLE KEYS */;
/*!40000 ALTER TABLE `depreciations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `groups_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'Admin','{\"admin\":1,\"users\":1,\"reports\":1}','2016-07-11 17:55:41','2016-07-11 17:55:41'),(2,'Reporting','{\"users\":1,\"reports\":1}','2016-07-11 17:55:41','2016-07-11 17:55:41'),(3,'Users','{\"users\":1}','2016-07-11 17:55:41','2016-07-11 17:55:41');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `checkedout_to` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `license_seats`
--

DROP TABLE IF EXISTS `license_seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `license_seats` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `license_id` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `asset_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `license_seats`
--

LOCK TABLES `license_seats` WRITE;
/*!40000 ALTER TABLE `license_seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `license_seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licenses`
--

DROP TABLE IF EXISTS `licenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `licenses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `serial` text COLLATE utf8_unicode_ci,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(13,4) DEFAULT NULL,
  `order_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seats` int(11) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8_unicode_ci,
  `user_id` int(11) NOT NULL,
  `depreciation_id` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `license_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license_email` varchar(120) COLLATE utf8_unicode_ci DEFAULT NULL,
  `depreciate` tinyint(1) DEFAULT '0',
  `supplier_id` int(11) DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `purchase_order` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `termination_date` date DEFAULT NULL,
  `maintained` tinyint(1) NOT NULL,
  `reassignable` tinyint(1) NOT NULL DEFAULT '1',
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licenses`
--

LOCK TABLES `licenses` WRITE;
/*!40000 ALTER TABLE `licenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `licenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `address` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `address2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Offices','Waimea','HI','US','2016-07-11 18:09:32','2016-07-11 18:09:32',1,'','','96743',NULL,NULL,'$'),(2,'Summit','Mauna Kea','','US','2016-07-11 18:16:11','2016-07-11 18:16:11',1,'','','',NULL,NULL,'$');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manufacturers`
--

DROP TABLE IF EXISTS `manufacturers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manufacturers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manufacturers`
--

LOCK TABLES `manufacturers` WRITE;
/*!40000 ALTER TABLE `manufacturers` DISABLE KEYS */;
INSERT INTO `manufacturers` VALUES (1,'Supermicro','2016-07-11 18:13:58','2016-07-11 18:13:58',1,NULL);
/*!40000 ALTER TABLE `manufacturers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2012_12_06_225921_migration_cartalyst_sentry_install_users',1),('2012_12_06_225929_migration_cartalyst_sentry_install_groups',1),('2012_12_06_225945_migration_cartalyst_sentry_install_users_groups_pivot',1),('2012_12_06_225988_migration_cartalyst_sentry_install_throttle',1),('2013_03_23_193214_update_users_table',2),('2013_11_13_075318_create_models_table',2),('2013_11_13_075335_create_categories_table',2),('2013_11_13_075347_create_manufacturers_table',2),('2013_11_15_015858_add_user_id_to_categories',2),('2013_11_15_112701_add_user_id_to_manufacturers',2),('2013_11_15_190327_create_assets_table',2),('2013_11_15_190357_create_licenses_table',2),('2013_11_15_201848_add_license_name_to_licenses',2),('2013_11_16_040323_create_depreciations_table',2),('2013_11_16_042851_add_depreciation_id_to_models',2),('2013_11_16_084923_add_user_id_to_models',2),('2013_11_16_103258_create_locations_table',2),('2013_11_16_103336_add_location_id_to_assets',2),('2013_11_16_103407_add_checkedout_to_to_assets',2),('2013_11_16_103425_create_history_table',2),('2013_11_17_054359_drop_licenses_table',2),('2013_11_17_054526_add_physical_to_assets',2),('2013_11_17_055126_create_settings_table',2),('2013_11_17_062634_add_license_to_assets',2),('2013_11_18_134332_add_contacts_to_users',2),('2013_11_18_142847_add_info_to_locations',2),('2013_11_18_152942_remove_location_id_from_asset',2),('2013_11_18_164423_set_nullvalues_for_user',2),('2013_11_19_013337_create_asset_logs_table',2),('2013_11_19_061409_edit_added_on_asset_logs_table',2),('2013_11_19_062250_edit_location_id_asset_logs_table',2),('2013_11_20_055822_add_soft_delete_on_assets',2),('2013_11_20_121404_add_soft_delete_on_locations',2),('2013_11_20_123137_add_soft_delete_on_manufacturers',2),('2013_11_20_123725_add_soft_delete_on_categories',2),('2013_11_20_130248_create_status_labels',2),('2013_11_20_130830_add_status_id_on_assets_table',2),('2013_11_20_131544_add_status_type_on_status_labels',2),('2013_11_20_134103_add_archived_to_assets',2),('2013_11_21_002321_add_uploads_table',2),('2013_11_21_024531_remove_deployable_boolean_from_status_labels',2),('2013_11_22_075308_add_option_label_to_settings_table',2),('2013_11_22_213400_edits_to_settings_table',2),('2013_11_25_013244_create_licenses_table',2),('2013_11_25_031458_create_license_seats_table',2),('2013_11_25_032022_add_type_to_actionlog_table',2),('2013_11_25_033008_delete_bad_licenses_table',2),('2013_11_25_033131_create_new_licenses_table',2),('2013_11_25_033534_add_licensed_to_licenses_table',2),('2013_11_25_101308_add_warrantee_to_assets_table',2),('2013_11_25_104343_alter_warranty_column_on_assets',2),('2013_11_25_150450_drop_parent_from_categories',2),('2013_11_25_151920_add_depreciate_to_assets',2),('2013_11_25_152903_add_depreciate_to_licenses_table',2),('2013_11_26_211820_drop_license_from_assets_table',2),('2013_11_27_062510_add_note_to_asset_logs_table',2),('2013_12_01_113426_add_filename_to_asset_log',2),('2013_12_06_094618_add_nullable_to_licenses_table',2),('2013_12_10_084038_add_eol_on_models_table',2),('2013_12_12_055218_add_manager_to_users_table',2),('2014_01_28_031200_add_qr_code_to_settings_table',2),('2014_02_13_183016_add_qr_text_to_settings_table',2),('2014_05_24_093839_alter_default_license_depreciation_id',2),('2014_05_27_231658_alter_default_values_licenses',2),('2014_06_19_191508_add_asset_name_to_settings',2),('2014_06_20_004847_make_asset_log_checkedout_to_nullable',2),('2014_06_20_005050_make_asset_log_purchasedate_to_nullable',2),('2014_06_24_003011_add_suppliers',2),('2014_06_24_010742_add_supplier_id_to_asset',2),('2014_06_24_012839_add_zip_to_supplier',2),('2014_06_24_033908_add_url_to_supplier',2),('2014_07_08_054116_add_employee_id_to_users',2),('2014_07_09_134316_add_requestable_to_assets',2),('2014_07_17_085822_add_asset_to_software',2),('2014_07_17_161625_make_asset_id_in_logs_nullable',2),('2014_08_12_053504_alpha_0_4_2_release',2),('2014_08_17_083523_make_location_id_nullable',2),('2014_10_16_200626_add_rtd_location_to_assets',2),('2014_10_24_000417_alter_supplier_state_to_32',2),('2014_10_24_015641_add_display_checkout_date',2),('2014_10_28_222654_add_avatar_field_to_users_table',2),('2014_10_29_045924_add_image_field_to_models_table',2),('2014_11_01_214955_add_eol_display_to_settings',2),('2014_11_04_231416_update_group_field_for_reporting',2),('2014_11_05_212408_add_fields_to_licenses',2),('2014_11_07_021042_add_image_to_supplier',2),('2014_11_20_203007_add_username_to_user',2),('2014_11_20_223947_add_auto_to_settings',2),('2014_11_20_224421_add_prefix_to_settings',2),('2014_11_21_104401_change_licence_type',2),('2014_12_09_082500_add_fields_maintained_term_to_licenses',2),('2015_02_04_155757_increase_user_field_lengths',2),('2015_02_07_013537_add_soft_deleted_to_log',2),('2015_02_10_040958_fix_bad_assigned_to_ids',2),('2015_02_10_053310_migrate_data_to_new_statuses',2),('2015_02_11_044104_migrate_make_license_assigned_null',2),('2015_02_11_104406_migrate_create_requests_table',2),('2015_02_12_001312_add_mac_address_to_asset',2),('2015_02_12_024100_change_license_notes_type',2),('2015_02_17_231020_add_localonly_to_settings',2),('2015_02_19_222322_add_logo_and_colors_to_settings',2),('2015_02_24_072043_add_alerts_to_settings',2),('2015_02_25_022931_add_eula_fields',2),('2015_02_25_204513_add_accessories_table',2),('2015_02_26_091228_add_accessories_user_table',2),('2015_02_26_115128_add_deleted_at_models',2),('2015_02_26_233005_add_category_type',2),('2015_03_01_231912_update_accepted_at_to_acceptance_id',2),('2015_03_05_011929_add_qr_type_to_settings',2),('2015_03_18_055327_add_note_to_user',2),('2015_04_29_234704_add_slack_to_settings',2),('2015_05_04_085151_add_parent_id_to_locations_table',2),('2015_05_22_124421_add_reassignable_to_licenses',2),('2015_06_10_003314_fix_default_for_user_notes',2),('2015_06_10_003554_create_consumables',2),('2015_06_15_183253_move_email_to_username',2),('2015_06_23_070346_make_email_nullable',2),('2015_06_26_213716_create_asset_maintenances_table',2),('2015_07_04_212443_create_custom_fields_table',2),('2015_07_09_014359_add_currency_to_settings_and_locations',2),('2015_07_21_122022_add_expected_checkin_date_to_asset_logs',2),('2015_07_24_093845_add_checkin_email_to_category_table',2),('2015_07_25_055415_remove_email_unique_constraint',2),('2015_07_29_230054_add_thread_id_to_asset_logs_table',2),('2015_07_31_015430_add_accepted_to_assets',2),('2015_09_09_195301_add_custom_css_to_settings',2),('2015_09_21_235926_create_custom_field_custom_fieldset',2),('2015_09_22_000104_create_custom_fieldsets',2),('2015_09_22_003321_add_fieldset_id_to_assets',2),('2015_09_22_003413_migrate_mac_address',2),('2015_09_28_003314_fix_default_purchase_order',2),('2015_10_01_024551_add_accessory_consumable_price_info',2),('2015_10_12_192706_add_brand_to_settings',2),('2015_10_22_003314_fix_defaults_accessories',2),('2015_10_23_182625_add_checkout_time_and_expected_checkout_date_to_assets',2),('2015_11_05_061015_create_companies_table',2),('2015_11_05_061115_add_company_id_to_consumables_table',2),('2015_11_05_183749_image',2),('2015_11_06_092038_add_company_id_to_accessories_table',2),('2015_11_06_100045_add_company_id_to_users_table',2),('2015_11_06_134742_add_company_id_to_licenses_table',2),('2015_11_08_035832_add_company_id_to_assets_table',2),('2015_11_08_222305_add_ldap_fields_to_settings',2),('2015_11_15_151803_add_full_multiple_companies_support_to_settings_table',2),('2015_11_26_195528_import_ldap_settings',2),('2015_11_30_191504_remove_fk_company_id',2),('2015_12_21_193006_add_ldap_server_cert_ignore_to_settings_table',2),('2015_12_30_233509_add_timestamp_and_userId_to_custom_fields',2),('2015_12_30_233658_add_timestamp_and_userId_to_custom_fieldsets',2),('2016_01_28_041048_add_notes_to_models',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `models`
--

DROP TABLE IF EXISTS `models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `models` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `modelno` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturer_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `depreciation_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `eol` int(11) DEFAULT '0',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deprecated_mac_address` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `fieldset_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `models`
--

LOCK TABLES `models` WRITE;
/*!40000 ALTER TABLE `models` DISABLE KEYS */;
INSERT INTO `models` VALUES (1,'Supermicro','',1,7,'2016-07-11 18:15:45','2016-07-11 18:32:34',0,1,0,NULL,0,NULL,6,'');
/*!40000 ALTER TABLE `models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requested_assets`
--

DROP TABLE IF EXISTS `requested_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requested_assets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `denied_at` datetime DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requested_assets`
--

LOCK TABLES `requested_assets` WRITE;
/*!40000 ALTER TABLE `requested_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `requested_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requests`
--

DROP TABLE IF EXISTS `requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `request_code` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requests`
--

LOCK TABLES `requests` WRITE;
/*!40000 ALTER TABLE `requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `per_page` int(11) NOT NULL DEFAULT '20',
  `site_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Snipe IT Asset Management',
  `qr_code` int(11) DEFAULT NULL,
  `qr_text` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_asset_name` int(11) DEFAULT NULL,
  `display_checkout_date` int(11) DEFAULT NULL,
  `display_eol` int(11) DEFAULT NULL,
  `auto_increment_assets` int(11) NOT NULL DEFAULT '0',
  `auto_increment_prefix` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `load_remote` tinyint(1) NOT NULL DEFAULT '1',
  `logo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `header_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alert_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alerts_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `default_eula_text` longtext COLLATE utf8_unicode_ci,
  `barcode_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'QRCODE',
  `slack_endpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slack_channel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slack_botname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `default_currency` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `custom_css` text COLLATE utf8_unicode_ci,
  `brand` tinyint(4) NOT NULL DEFAULT '1',
  `ldap_enabled` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_server` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_uname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_pword` longtext COLLATE utf8_unicode_ci,
  `ldap_basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_filter` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'cn=*',
  `ldap_username_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'samaccountname',
  `ldap_lname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'sn',
  `ldap_fname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'givenname',
  `ldap_auth_filter_query` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid=samaccountname',
  `ldap_version` int(11) DEFAULT '3',
  `ldap_active_flag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_emp_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_multiple_companies_support` tinyint(1) NOT NULL DEFAULT '0',
  `ldap_server_cert_ignore` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'2016-07-11 17:55:41','2016-07-11 19:27:30',1,150,'Canada France Hawaii Telescope (BETA)',1,'',NULL,NULL,NULL,1,'CFHT-',1,NULL,'#2196f3','software@cfht.hawaii.edu',1,'','QRCODE','','','','$','',1,'1','ldaps://kalij.cfht.hawaii.edu','uid=assetadmin,cn=users,cn=accounts,dc=cfht,dc=hawaii,dc=edu','eyJpdiI6IjFYNkNTNWo2ZFdINEpPRHdJV3hxVFJXR0M2cDVTWkl1c0N5R1IxYnd6dUE9IiwidmFsdWUiOiJyZWFaWkF4ZkJkdnJibysxSE9zdnA5WCtXRkhjbmo3aTFUZ3FLY0FSNUNnPSIsIm1hYyI6IjQ3ZTViNDIwNjhiNDAxODBjNjgzNDQwY2M0OTE2YjM3MmM1ZDIxODA1MzBhMjcxYjJiZGNiZGE1ZmEyNWRjOTEifQ==','dc=cfht,dc=hawaii,dc=edu','&(objectclass=*)(memberof=cn=redprog,cn=groups,cn=accounts,dc=cfht,dc=hawaii,dc=edu)','uid','sn','givenname','uid=',3,'active','','mail',0,1);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status_labels`
--

DROP TABLE IF EXISTS `status_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_labels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deployable` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_labels`
--

LOCK TABLES `status_labels` WRITE;
/*!40000 ALTER TABLE `status_labels` DISABLE KEYS */;
INSERT INTO `status_labels` VALUES (1,'Ready to Deploy',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,1,0,0,''),(2,'Pending',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,0,1,0,''),(3,'Archived',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,0,0,1,'These assets are permanently undeployable'),(4,'Out for Diagnostics',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,0,0,0,''),(5,'Out for Repair',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,0,0,0,''),(6,'Broken - Not Fixable',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,0,0,1,''),(7,'Lost/Stolen',1,'2016-04-11 17:55:41','2016-04-11 17:55:41',NULL,0,0,1,'');
/*!40000 ALTER TABLE `status_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `zip` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `throttle`
--

DROP TABLE IF EXISTS `throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `throttle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `attempts` int(11) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `last_attempt_at` timestamp NULL DEFAULT NULL,
  `suspended_at` timestamp NULL DEFAULT NULL,
  `banned_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `throttle_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `throttle`
--

LOCK TABLES `throttle` WRITE;
/*!40000 ALTER TABLE `throttle` DISABLE KEYS */;
INSERT INTO `throttle` VALUES (1,1,'128.171.80.232',0,0,0,NULL,NULL,NULL),(2,11,'128.171.80.232',0,0,0,NULL,NULL,NULL),(3,1,'10.80.10.177',0,0,0,NULL,NULL,NULL),(4,12,'128.171.80.232',0,0,0,NULL,NULL,NULL),(5,1,'10.80.10.98',0,0,0,NULL,NULL,NULL),(6,11,'10.80.10.53',0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `throttle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `permissions` text COLLATE utf8_unicode_ci,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `activation_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `persist_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jobtitle` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `employee_num` text COLLATE utf8_unicode_ci,
  `avatar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_activation_code_index` (`activation_code`),
  KEY `users_reset_password_code_index` (`reset_password_code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'software@cfht.hawaii.edu','$2y$08$fGsyjkTcKf1i0L2bqgeHyO..SHIxOU7A2YK/agkIJef3PrOzpGoBS','{\"admin\":1,\"user\":1,\"superuser\":1,\"reports\":1}',1,NULL,NULL,'2016-07-11 20:06:01','$2y$08$tJzZJSUrykNxyWn2iaRQh.XCC0ilTtT14iHqcXp89F.GT3uOTO6k6',NULL,'admin','snipeit','2016-07-11 17:55:41','2016-07-11 20:06:01',NULL,NULL,NULL,NULL,NULL,'','',NULL,'',NULL,'admin','Generated on install',NULL),(2,'kuotiong@cfht.hawaii.edu','$2y$08$qAMGm5E8V2t65WqThOJjj.xFrB36X.3/39jIZBaqQW.xvMqLSWWQ2','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'Blaise','C. Kuotiong','0000-00-00 00:00:00','2016-07-11 18:35:23',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'kuotiong','Imported from LDAP',1),(3,'postgres@cfht.hawaii.edu','$2y$08$2C6m7UhLgZErP3JheN2j8Ohspcho.l3gxwoD1NF7Ll8JJMehxLwIC','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'Postgres','User','0000-00-00 00:00:00','2016-07-11 18:36:34',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'postgres','Imported from LDAP',1),(4,'babas@cfht.hawaii.edu','$2y$08$QzKQ4N9kMqr0Ano50OW0bOlN55NQQj3NUgGGQYyQdu7hvLZN/Xnfe','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'Ferdinand','Babas','0000-00-00 00:00:00','2016-07-11 18:35:39',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'babas','Imported from LDAP',1),(5,'thomas@cfht.hawaii.edu','$2y$08$GT5z17no6TiFY5vZXVb8JeDjFQq/fO22CMm/9lAa/MX/elTp197tG','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'Jim','Thomas','0000-00-00 00:00:00','2016-07-11 18:36:09',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'thomas','Imported from LDAP',1),(6,'midas@cfht.hawaii.edu','$2y$08$rJTbfD1TiLmWsejwwVJNt.zQF5NuejK/Yr4urkT3F3cwmjOwqP86.','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'MIDAS','Guru','0000-00-00 00:00:00','2016-07-11 18:36:25',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'midas','Imported from LDAP',1),(7,'dos@cfht.hawaii.edu','$2y$08$VJt1IDnxv3dY2UzuNc4Yb.7Ph/FTJirZffLaaPaUYX/qmAwhSLvF6','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'DOS','Guru','0000-00-00 00:00:00','2016-07-11 18:35:32',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'dos','Imported from LDAP',1),(8,'kanoa@cfht.hawaii.edu','$2y$08$X8gjrtvIzcafIZBZX44AdODVvhvfOfZuep.FYSKFMpSCWXLAXegY2','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'Kanoa','Withington','0000-00-00 00:00:00','2016-07-11 18:36:18',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'kanoa','Imported from LDAP',1),(9,'nguyen@cfht.hawaii.edu','$2y$08$tFVCpEb4JhrCnA1XVHWTAO4az.2oabxQ7yCkA6v03aQ37RZ7X4EKu','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'Tien','Nguyen','0000-00-00 00:00:00','2016-07-11 18:36:40',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'nguyen','Imported from LDAP',1),(10,'iraf@cfht.hawaii.edu','$2y$08$z8XDbtWg4GorKQHXJy1OWee5wg.m4V21WFp9aYet3wwdD98GzR6Dy','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,NULL,NULL,NULL,'IRAF','Guru','0000-00-00 00:00:00','2016-07-11 18:35:58',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'iraf','Imported from LDAP',1),(11,'albano@cfht.hawaii.edu','$2y$08$BHfmLcLBadgNcNwghJH4z.VvUSPnEth21m1oCRnfK4rzANZZYee.G','{\"user\":1,\"superuser\":-1}',1,NULL,NULL,'2016-07-14 02:27:11','$2y$08$twVniwV7BjQLnwLniqkWm.5VRuNRaZeZISSwUTKNa6RV0RvCF2yUO',NULL,'Daryl','Albano','0000-00-00 00:00:00','2016-07-14 02:27:11',NULL,NULL,NULL,NULL,1,'','',NULL,'',NULL,'albano','Imported from LDAP',1),(12,'','$2y$08$Olr3AulbOQZACseZ0NP0ieHYvYxVmJargkvBkzPql1wTbLjRdmLRG','{\"superuser\":-1}',1,NULL,NULL,'2016-07-11 18:51:05','$2y$08$XyMtepGSOZdo7Z7aYaNLmu6Ni3s17XBUMIDV897RzwCGMCdMg1KXO',NULL,'test','user','2016-07-11 18:49:10','2016-07-11 18:51:05',NULL,NULL,NULL,NULL,NULL,'','',NULL,'',NULL,'user','',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_groups` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_groups`
--

LOCK TABLES `users_groups` WRITE;
/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,3);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-14 13:39:02
